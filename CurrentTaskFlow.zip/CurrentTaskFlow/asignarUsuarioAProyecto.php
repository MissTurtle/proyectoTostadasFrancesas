<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include "funciones.php";
include "sendMail.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];

try {
    // Obtener lista de usuarios activos y no asignados al proyecto, excluyendo administradores
    $stmt = $con->prepare("SELECT u.dni, u.nombre, u.email, u.rol 
                           FROM usuarios u 
                           LEFT JOIN proyectos_usuarios pu ON u.dni = pu.dniUsuario AND pu.proyecto_id = :proyecto_id 
                           WHERE u.activo = 1 AND pu.proyecto_id IS NULL AND u.rol != 'Administrador'");
    $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener lista de usuarios asignados al proyecto
    $stmt = $con->prepare("SELECT u.dni, u.nombre, u.email, u.rol 
                           FROM usuarios u 
                           JOIN proyectos_usuarios pu ON u.dni = pu.dniUsuario 
                           WHERE pu.proyecto_id = :proyecto_id AND u.activo = 1");
    $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $usuariosAsignados = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error al obtener usuarios: " . $e->getMessage();
    exit();
}

// Asignar usuario al proyecto
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dniUsuario'])) {
    $dniUsuario = $_POST['dniUsuario'];

    try {
        $stmt = $con->prepare("INSERT INTO proyectos_usuarios (proyecto_id, dniUsuario) VALUES (:proyecto_id, :dniUsuario)");
        $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);
        $stmt->execute();

        // Obtener el correo electrónico del usuario asignado
        $stmt = $con->prepare("SELECT email FROM usuarios WHERE dni = :dniUsuario");
        $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);
        $stmt->execute();
        $emailUsuario = $stmt->fetchColumn();

        // Obtener el nombre del proyecto
        $stmt = $con->prepare("SELECT nombreProyecto FROM proyectos WHERE id = :proyecto_id");
        $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $nombreProyecto = $stmt->fetchColumn();

        // Enviar correo electrónico al usuario asignado con el nombre del proyecto
        $subject = "Asignación a Proyecto";
        $body = "Ha sido asignado al proyecto '$nombreProyecto'. Por favor, inicie sesión para más detalles.";
        sendMail($emailUsuario, $subject, $body);

        echo "<script>alert('Usuario asignado con éxito.'); window.location.href = 'asignarUsuarioAProyecto.php?id=$id';</script>";
    } catch (PDOException $e) {
        echo "Error al asignar usuario: " . $e->getMessage();
        exit();
    }
}

// Desasignar usuario del proyecto
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dniUsuarioDesasignar'])) {
    $dniUsuarioDesasignar = $_POST['dniUsuarioDesasignar'];

    try {
        $stmt = $con->prepare("DELETE FROM proyectos_usuarios WHERE proyecto_id = :proyecto_id AND dniUsuario = :dniUsuario");
        $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':dniUsuario', $dniUsuarioDesasignar, PDO::PARAM_STR);
        $stmt->execute();

        // Obtener el correo electrónico del usuario desasignado
        $stmt = $con->prepare("SELECT email FROM usuarios WHERE dni = :dniUsuario");
        $stmt->bindParam(':dniUsuario', $dniUsuarioDesasignar, PDO::PARAM_STR);
        $stmt->execute();
        $emailUsuario = $stmt->fetchColumn();

        // Obtener el nombre del proyecto
        $stmt = $con->prepare("SELECT nombreProyecto FROM proyectos WHERE id = :proyecto_id");
        $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $nombreProyecto = $stmt->fetchColumn();

        // Enviar correo electrónico al usuario desasignado con el nombre del proyecto
        $subject = "Desasignación de Proyecto";
        $body = "Ha sido desasignado del proyecto '$nombreProyecto'. Por favor, inicie sesión para más detalles.";
        sendMail($emailUsuario, $subject, $body);

        echo "<script>alert('Usuario desasignado con éxito.'); window.location.href = 'asignarUsuarioAProyecto.php?id=$id';</script>";
    } catch (PDOException $e) {
        echo "Error al desasignar usuario: " . $e->getMessage();
        exit();
    }
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Asignar Usuarios</h2>
        <a href="mostrarProyectos.php" class="btn btn-primary text-light">Volver</a>
    </div>
    <h4 class="card-title">Usuarios asignados al Proyecto</h4><br>
        <form method="POST" action="">
            <div class="form-group">
                <select class="form-control w-25" id="dniUsuarioDesasignar" name="dniUsuarioDesasignar" required>
                    <?php if (empty($usuariosAsignados)): ?>
                        <option value="">No hay usuarios asignados</option>
                    <?php else: ?>
                        <option value="" disabled selected>Seleccione un usuario</option>
                        <?php foreach ($usuariosAsignados as $usuarioAsignado): ?>
                            <option value="<?php echo htmlspecialchars($usuarioAsignado['dni']); ?>">
                                <?php echo htmlspecialchars($usuarioAsignado['nombre'] . " (" . $usuarioAsignado['rol'] . ")"); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <br><button type="submit" class="btn btn-danger text-light" <?php echo empty($usuariosAsignados) ? 'disabled' : ''; ?>>Desasignar</button><br><br>
        </form>
        <h4 class="card-title">Usuarios disponibles para asignar al Proyecto</h4><br>
        <form method="POST" action="">
            <div class="form-group">
                <select class="form-control w-25" id="dniUsuario" name="dniUsuario" required>
                    <?php if (empty($usuarios)): ?>
                        <option value="">No hay usuarios disponibles para asignar</option>
                    <?php else: ?>
                        <option value="" disabled selected>Seleccione un usuario</option>
                        <?php foreach ($usuarios as $usuario): ?>
                            <option value="<?php echo htmlspecialchars($usuario['dni']); ?>">
                                <?php echo htmlspecialchars($usuario['nombre'] . " (" . $usuario['rol'] . ")"); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <br><button type="submit" class="btn btn-primary text-light" <?php echo empty($usuarios) ? 'disabled' : ''; ?>>Asignar</button><br><br>
        </form>
</main>

<?php
include "footer.php";
$con = null;
?>