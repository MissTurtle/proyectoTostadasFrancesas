<?php
session_start();
include "funciones.php";
include "header.php";
?>

<main class="container">
    <div class="panel panel-default">
        <div class="panel-body">
            <h2>Contacto</h2>
            <p class="text-primary">Correo Electrónico: info@currenttaskflow.com</p>
            <p class="text-primary">Teléfono: +34 123 456 789</p>
            <p class="text-primary">Dirección: C/ Ficticia, nº 12, CP 34567, Ciudad Imaginaria</p>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>