<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include "funciones.php";
include "sendMail.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idProyecto = $_POST["id"];
    $nombreProyecto = $_POST["nombreProyecto"];
    $descripcionProyecto = $_POST["descripcionProyecto"];
    $repositorio = $_POST["repositorio"];
    $fechaFinalizacionPrevista = $_POST["fechaFinalizacionPrevista"];
    $estadoProyecto = $_POST["estadoProyecto"];
    $activo = isset($_POST["activo"]) ? 1 : 0;

    try {
        // Obtener el estado anterior del proyecto
        $sqlEstadoAnterior = "SELECT estadoProyecto FROM proyectos WHERE id = :idProyecto";
        $stmtEstadoAnterior = $con->prepare($sqlEstadoAnterior);
        $stmtEstadoAnterior->bindParam(":idProyecto", $idProyecto);
        $stmtEstadoAnterior->execute();
        $estadoAnterior = $stmtEstadoAnterior->fetchColumn();

        // Consulta SQL para actualizar el proyecto (sin actualizar dniUsuario)
        $sqlProyecto = "UPDATE proyectos
                        SET nombreProyecto = :nombreProyecto, descripcionProyecto = :descripcionProyecto, repositorio = :repositorio, 
                            fechaFinalizacionPrevista = :fechaFinalizacionPrevista, 
                            estadoProyecto = :estadoProyecto, activo = :activo
                        WHERE id = :idProyecto";

        $stmtProyecto = $con->prepare($sqlProyecto);
        $stmtProyecto->bindParam(":idProyecto", $idProyecto);
        $stmtProyecto->bindParam(":nombreProyecto", $nombreProyecto);
        $stmtProyecto->bindParam(":descripcionProyecto", $descripcionProyecto);
        $stmtProyecto->bindParam(":repositorio", $repositorio);
        $stmtProyecto->bindParam(":fechaFinalizacionPrevista", $fechaFinalizacionPrevista);
        $stmtProyecto->bindParam(":estadoProyecto", $estadoProyecto);
        $stmtProyecto->bindParam(":activo", $activo);
        $stmtProyecto->execute();

        // Actualizar las fechas de finalización de las tareas asociadas al proyecto solo si la nueva fecha del proyecto deja a alguna tarea fuera de rango
        $sqlTareas = "SELECT id, fechaFinalizacionPrevista FROM tareas WHERE proyecto_id = :idProyecto";
        $stmtTareas = $con->prepare($sqlTareas);
        $stmtTareas->bindParam(":idProyecto", $idProyecto);
        $stmtTareas->execute();
        $tareas = $stmtTareas->fetchAll(PDO::FETCH_ASSOC);

        foreach ($tareas as $tarea) {
            if ($tarea['fechaFinalizacionPrevista'] > $fechaFinalizacionPrevista) {
                // Si la fecha de la tarea está después de la nueva fecha de finalización del proyecto, actualiza la fecha de la tarea
                $sqlUpdateTarea = "UPDATE tareas SET fechaFinalizacionPrevista = DATE_SUB(:fechaFinalizacionPrevista, INTERVAL 1 DAY) WHERE id = :idTarea";
                $stmtUpdateTarea = $con->prepare($sqlUpdateTarea);
                $stmtUpdateTarea->bindParam(":fechaFinalizacionPrevista", $fechaFinalizacionPrevista);
                $stmtUpdateTarea->bindParam(":idTarea", $tarea['id']);
                $stmtUpdateTarea->execute();
            }
        }

        // Obtener el DNI del usuario que creó el proyecto
        $sqlDNIUsuario = "SELECT dniUsuario FROM proyectos WHERE id = :idProyecto";
        $stmtDNIUsuario = $con->prepare($sqlDNIUsuario);
        $stmtDNIUsuario->bindParam(":idProyecto", $idProyecto);
        $stmtDNIUsuario->execute();
        $dniUsuarioProyecto = $stmtDNIUsuario->fetchColumn();

        // Obtener la información completa del usuario que creó el proyecto
        $sqlUsuario = "SELECT * FROM usuarios WHERE dni = :dniUsuarioProyecto";
        $stmtUsuario = $con->prepare($sqlUsuario);
        $stmtUsuario->bindParam(":dniUsuarioProyecto", $dniUsuarioProyecto);
        $stmtUsuario->execute();
        $usuarioProyecto = $stmtUsuario->fetch(PDO::FETCH_ASSOC);

        // Enviar correo solo si ha cambiado el estado del proyecto
        if ($estadoAnterior !== $estadoProyecto) {
            $mensajePersonalizado = "El proyecto \"" . $nombreProyecto . "\" ha cambiado a: " . $estadoProyecto;

            // Enviar un correo electrónico al creador del proyecto
            $to = $usuarioProyecto['email'];
            $subject = "Cambio de estado de proyecto";
            $body = $mensajePersonalizado . ".<br><br>Entra en CurrentTaskFlow para más detalles.";
            sendMail($to, $subject, $body);

            $jsAlert = "alert('Cambios guardados correctamente. Se ha enviado un correo electrónico al jefe de proyecto.');";
        } else {
            $jsAlert = "alert('Cambios guardados correctamente.');";
        }

        $redirect = "window.location.href = 'mostrarProyectos.php';";
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarProyectos.php';";
    }
}

if (isset($_GET["id"])) {
    $idProyecto = $_GET["id"];

    try {
        // Obtener información del proyecto
        $sqlProyecto = "SELECT * FROM proyectos WHERE id = :idProyecto";
        $stmtProyecto = $con->prepare($sqlProyecto);
        $stmtProyecto->bindParam(":idProyecto", $idProyecto);
        $stmtProyecto->execute();
        $proyecto = $stmtProyecto->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarProyectos.php';";
    }
} else {
    $redirect = "window.location.href = 'mostrarProyectos.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
<div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Introduce los nuevos datos del proyecto</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formedi" method="POST" enctype="multipart/form-data" onsubmit="return validarFechas()">
        <div class="mb-3">
            <input type="hidden" class="form-control" name="id" value="<?php echo $proyecto['id']; ?>">
        </div>
        <div class="mb-3">
            <label for="nombreProyecto" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombreProyecto" value="<?php echo $proyecto['nombreProyecto']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="descripcionProyecto" class="form-label">Descripción del Proyecto:</label>
            <textarea class="form-control w-25" name="descripcionProyecto" rows="4" required><?php echo $proyecto['descripcionProyecto']; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="repositorio" class="form-label">Repositorio del proyecto:</label>
            <input type="text" class="form-control w-25" name="repositorio" value="<?php echo $proyecto['repositorio']; ?>">
        </div>
        <div class="mb-3">
            <label for="fechaFinalizacionPrevista" class="form-label">Fecha de Finalización Prevista:</label>
            <input type="date" class="form-control w-25" id="fechaFinalizacionPrevista" name="fechaFinalizacionPrevista" value="<?php echo $proyecto['fechaFinalizacionPrevista']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="estadoProyecto" class="form-label">Estado del Proyecto:</label>
            <select name="estadoProyecto" required>
                <option value="Iniciado" <?php echo ($proyecto['estadoProyecto'] == 'Iniciado') ? 'selected' : ''; ?>>Iniciado</option>
                <option value="Finalizado" <?php echo ($proyecto['estadoProyecto'] == 'Finalizado') ? 'selected' : ''; ?>>Finalizado</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" <?php echo $proyecto["activo"] ? "checked" : ""; ?>>
        </div>
        <input type="submit" class="btn btn-primary text-light" name="actualizar" value="Actualizar Datos"><br><br>
    </form>
</main>

<script>
    function validarFechas() {
        // Obtener la fecha actual
        var fechaActual = new Date();
        var dd = String(fechaActual.getDate()).padStart(2, '0');
        var mm = String(fechaActual.getMonth() + 1).padStart(2, '0');
        var yyyy = fechaActual.getFullYear();
        var fechaActualStr = yyyy + '-' + mm + '-' + dd;

        var fechaFinalizacion = document.getElementById("fechaFinalizacionPrevista").value;

        // Comprobar si la fecha de finalización prevista es anterior a la actual
        if (fechaFinalizacion < fechaActualStr) {
            alert("La fecha de finalización prevista no puede ser anterior a la fecha actual.");
            return false;
        }
        return true;
    }
</script>

<?php
include "footer.php";
$con = null;
?>