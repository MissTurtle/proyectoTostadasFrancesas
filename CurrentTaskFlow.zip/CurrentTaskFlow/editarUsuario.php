<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dni = $_POST["dni"];
    $nombre = $_POST["nombre"];
    $direccion = $_POST["direccion"];
    $localidad = $_POST["localidad"];
    $provincia = $_POST["provincia"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];
    $contrasenya = $_POST["contrasenya"];
    $rol = $_POST["rol"];
    $activo = isset($_POST["activo"]) ? 1 : 0;

    try {
        // Consulta SQL para obtener la contraseña actual
        $sql_pass = "SELECT contrasenya FROM usuarios WHERE dni = :dni";
        $stmt_pass = $con->prepare($sql_pass);
        $stmt_pass->bindParam(":dni", $dni);
        $stmt_pass->execute();
        $fila_pass = $stmt_pass->fetch(PDO::FETCH_ASSOC);
        $pass_enc = $fila_pass['contrasenya'];

        // Si se proporciona una nueva contraseña, cifrarla
        if (!empty($contrasenya)) {
            $pass_enc = password_hash($contrasenya, PASSWORD_DEFAULT);
        }

        // Consulta SQL para actualizar los datos del usuario
        $sql_update = "UPDATE usuarios
                SET nombre = :nombre, direccion = :direccion, localidad = :localidad, provincia = :provincia,
                telefono = :telefono, email = :email, contrasenya = :contrasenya, rol = :rol, activo = :activo
                WHERE dni = :dni";
        $stmt_update = $con->prepare($sql_update);

        $stmt_update->bindParam(":dni", $dni);
        $stmt_update->bindParam(":nombre", $nombre);
        $stmt_update->bindParam(":direccion", $direccion);
        $stmt_update->bindParam(":localidad", $localidad);
        $stmt_update->bindParam(":provincia", $provincia);
        $stmt_update->bindParam(":telefono", $telefono);
        $stmt_update->bindParam(":email", $email);
        $stmt_update->bindParam(":contrasenya", $pass_enc);
        $stmt_update->bindParam(":rol", $rol);
        $stmt_update->bindParam(":activo", $activo);

        $stmt_update->execute();

        $jsAlert = "alert('Cambios guardados correctamente.');";
        $redirect = "window.location.href = 'mostrarUsuarios.php';";
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarUsuarios.php';";
    }
}

if (isset($_GET["dni"])) {
    $dni = $_GET["dni"];

    try {
        // Busco al usuario
        $sql = "SELECT * FROM usuarios WHERE dni = :dni";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":dni", $dni);
        $stmt->execute();
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        // Oculto el campo rol si el DNI que voy a modificar coincide con el de un jefe, un empleado o un usuario (la variable se usa en el formulario, y uso CSS para ocultar)
        $ocultarRol = ($_SESSION["dni"] == $fila["dni"] && $fila["rol"] == "usuario" || $_SESSION["dni"] == $fila["dni"] && $fila["rol"] == "Empleado" || $_SESSION["dni"] == $fila["dni"] && $fila["rol"] == "Jefe");
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarUsuarios.php';";
    }
} else {
    $redirect = "window.location.href = 'mostrarUsuarios.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Introduce los nuevos datos del usuario</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formedi" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <input type="hidden" class="form-control w-25" name="dni" value="<?php echo $fila['dni']; ?>">
        </div>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombre" value="<?php echo $fila['nombre']; ?>" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="direccion" class="form-label">Direccion:</label>
            <input type="text" class="form-control w-25" name="direccion" value="<?php echo $fila['direccion']; ?>" maxlength="50" required>
        </div>
        <div class="mb-3">
            <label for="localidad" class="form-label">Localidad:</label>
            <input type="text" class="form-control w-25" name="localidad" value="<?php echo $fila['localidad']; ?>" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="provincia" class="form-label">Provincia:</label>
            <input type="text" class="form-control w-25" name="provincia" value="<?php echo $fila['provincia']; ?>" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="telefono" class="form-label">Telefono:</label>
            <input type="tel" class="form-control w-25" name="telefono" value="<?php echo $fila['telefono']; ?>" pattern="[0-9]{9}" maxlength="9" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control w-25" name="email" value="<?php echo $fila['email']; ?>" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="contrasenya" class="form-label">Nueva Contraseña:</label>
            <input type="password" class="form-control w-25" name="contrasenya" placeholder="Deja en blanco para no cambiar" maxlength="9">
        </div>
        <div class="mb-3">
            <?php if (!$ocultarRol): ?>
            <label for="rol" class="form-label">Rol:</label>
            <?php endif; ?>
            <select name="rol" required <?php echo $ocultarRol ? 'style="display:none;"' : ''; ?>>
                <option value="Administrador" <?php echo ($fila["rol"] == "Administrador" && !$ocultarRol) ? "selected" : ""; ?>>Administrador</option>
                <option value="Jefe" <?php echo ($fila["rol"] == "Jefe" || $ocultarRol) ? "selected" : ""; ?>>Jefe</option>
                <option value="Empleado" <?php echo ($fila["rol"] == "Empleado" || $ocultarRol) ? "selected" : ""; ?>>Empleado</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" <?php echo $fila["activo"] ? "checked" : ""; ?>>
        </div>
        <input type="submit" class="btn btn-primary text-light" name="actualizar" value="Actualizar Datos"><br><br>
    </form>
</main>

<?php
include "footer.php";
$con = null;
?>