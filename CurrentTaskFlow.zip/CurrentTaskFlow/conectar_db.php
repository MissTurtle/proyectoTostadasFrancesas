<?php
define("HOSTNAME", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DATABASE", "tfgdaw");

try {
    $con = new PDO("mysql:host=" . HOSTNAME . ";dbname=" . DATABASE . ";charset=utf8mb4", USER, PASSWORD);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>