<?php
session_start();
include "funciones.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dni = $_POST["dni"];
    $nombre = $_POST["nombre"];
    $direccion = $_POST["direccion"];
    $localidad = $_POST["localidad"];
    $provincia = $_POST["provincia"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];
    $contrasenya = $_POST["contrasenya"];
    $rol = $_POST["rol"];
    $activo = isset($_POST["activo"]) ? 1 : 0;

    $funciones = new Funciones();

    // Compruebo que el DNI cumple los requisitos
    if ($funciones->validarDNI($dni)) {
        try {
            // Compruebo si el DNI ya existe
            $stmtComprobar = $con->prepare("SELECT dni FROM usuarios WHERE dni = :dni");
            $stmtComprobar->bindParam(":dni", $dni);
            $stmtComprobar->execute();

            if ($stmtComprobar->rowCount() > 0) {
                echo "<script>alert('Error: DNI ya registrado.'); window.history.back();</script>";
            } else {
                // Encripto la contraseña
                $pass_enc = password_hash($contrasenya, PASSWORD_DEFAULT);

                // Sentencia SQL
                $sql = "INSERT INTO usuarios (dni, nombre, direccion, localidad, provincia, telefono, email, contrasenya, rol, activo)
                        VALUES (:dni, :nombre, :direccion, :localidad, :provincia, :telefono, :email, :contrasenya, :rol, :activo)";

                // Consulta prepare
                $stmt = $con->prepare($sql);

                $stmt->bindParam(":dni", $dni);
                $stmt->bindParam(":nombre", $nombre);
                $stmt->bindParam(":direccion", $direccion);
                $stmt->bindParam(":localidad", $localidad);
                $stmt->bindParam(":provincia", $provincia);
                $stmt->bindParam(":telefono", $telefono);
                $stmt->bindParam(":email", $email);
                $stmt->bindParam(":contrasenya", $pass_enc);
                $stmt->bindParam(":rol", $rol);
                $stmt->bindParam(":activo", $activo);

                $stmt->execute();

                echo "<script>alert('Usuario registrado correctamente.'); window.location.href = 'index.php';</script>";
            }
        } catch (PDOException $e) {
            echo "<script>alert('Error: " . $e->getMessage() . "'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Error: DNI no válido.'); window.history.back();</script>";
    }
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Introduce los datos del nuevo usuario</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formncli" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="dni" class="form-label">DNI:</label>
            <input type="text" class="form-control w-25" name="dni" maxlength="9" required>
        </div>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombre" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="direccion" class="form-label">Direccion:</label>
            <input type="text" class="form-control w-25" name="direccion" maxlength="50" required>
        </div>
        <div class="mb-3">
            <label for="localidad" class="form-label">Localidad:</label>
            <input type="text" class="form-control w-25" name="localidad" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="provincia" class="form-label">Provincia:</label>
            <input type="text" class="form-control w-25" name="provincia" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="telefono" class="form-label">Telefono:</label>
            <input type="tel" class="form-control w-25" name="telefono" pattern="[0-9]{9}" maxlength="9" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control w-25" name="email" maxlength="30" required>
        </div>
        <div class="mb-3">
            <label for="contrasenya" class="form-label">Contrasenya:</label>
            <input type="password" class="form-control w-25" name="contrasenya" maxlength="9" required>
        </div>
        <div class="mb-3">
            <label for="rol" class="form-label">Rol:</label>
            <select name="rol" required>
                <option value="Administrador">Administrador</option>
                <option value="Jefe">Jefe</option>
                <option value="Empleado">Empleado</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" <?php echo isset($_POST["activo"]) && $_POST["activo"] == "1" ? "checked" : "checked"; ?>>
        </div>
        <div class="mb-3">
            <input type="reset" class="btn btn-primary text-light" name="Borrar" value="Borrar datos">
            <input type="submit" class="btn btn-primary text-light" name="Enviar" value="Enviar datos"><br><br>
        </div>
    </form>
</main>

<?php
include "footer.php";
$con = null;
?>