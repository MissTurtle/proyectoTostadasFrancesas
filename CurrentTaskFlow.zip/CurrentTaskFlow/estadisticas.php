<?php
session_start();
include "funciones.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

include "header.php";
?>

<main class="container">
    <h1>Estadísticas</h1>

    <div class="row">
        <div class="col-md-6">
            <div class="card mt-3">
                <div class="card-body">
                    <h2 class="card-title">Usuarios</h2>
                    <p class="text-primary">Total de usuarios registrados: 
                        <?php
                        $stmt = $con->query("SELECT COUNT(*) as cantidad FROM usuarios WHERE rol != 'Administrador'");
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo $row['cantidad'];
                        ?>
                    </p>
                    <p class="text-primary">Usuarios según su estado:</p>
                    <ul>
                        <li class="text-primary">Activos: 
                            <?php
                            $stmt = $con->query("SELECT COUNT(*) as cantidad FROM usuarios WHERE activo = 1 AND rol != 'Administrador'");
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['cantidad'];
                            ?>
                        </li>
                        <li class="text-primary">Inactivos: 
                            <?php
                            $stmt = $con->query("SELECT COUNT(*) as cantidad FROM usuarios WHERE activo = 0 AND rol != 'Administrador'");
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['cantidad'];
                            ?>
                        </li>
                    </ul>
                    <p class="text-primary">Usuarios según su rol:</p>
                    <ul>
                        <li class="text-primary">Jefes: 
                            <?php
                            $stmt = $con->query("SELECT COUNT(*) as cantidad FROM usuarios WHERE rol = 'jefe'");
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['cantidad'];
                            ?>
                        </li>
                        <li class="text-primary">Empleados: 
                            <?php
                            $stmt = $con->query("SELECT COUNT(*) as cantidad FROM usuarios WHERE rol = 'empleado'");
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['cantidad'];
                            ?>
                        </li>
                    </ul>
                    <p class="text-primary">Usuarios involucrados en proyectos: 
                        <?php
                        $stmt = $con->query("SELECT COUNT(DISTINCT dniUsuario) as cantidad FROM proyectos_usuarios");
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo $row['cantidad'];
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card mt-3">
                <div class="card-body">
                    <h2 class="card-title">Proyectos</h2>
                    <p class="text-primary">Activos:</p>
                    <ul class="text-primary">
                        <?php
                        $stmt = $con->query("SELECT estadoProyecto, COUNT(*) as cantidad FROM proyectos WHERE activo = 1 GROUP BY estadoProyecto");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo "<li>{$row['estadoProyecto']}: {$row['cantidad']}</li>";
                        }
                        ?>
                    </ul>
                    <p class="text-primary">Inactivos: 
                        <?php
                        $stmt = $con->query("SELECT COUNT(*) as cantidad FROM proyectos WHERE activo = 0");
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo $row['cantidad'];
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card mt-3">
                <div class="card-body">
                    <h2 class="card-title">Tareas</h2>
                    <p class="text-primary">Activas:</p>
                    <ul class="text-primary">
                        <?php
                        $stmt = $con->query("SELECT estadoTarea, COUNT(*) as cantidad FROM tareas WHERE activo = 1 GROUP BY estadoTarea");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo "<li>{$row['estadoTarea']}: {$row['cantidad']}</li>";
                        }
                        ?>
                    </ul>
                    <p class="text-primary">Inactivas: 
                        <?php
                        $stmt = $con->query("SELECT COUNT(*) as cantidad FROM tareas WHERE activo = 0");
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo $row['cantidad'];
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card mt-3 mb-3">
                <div class="card-body">
                    <h2 class="card-title">Notas</h2>
                    <p class="text-primary">Activas:</p>
                    <ul class="text-primary">
                        <?php
                        $stmt = $con->query("SELECT estadoNota, COUNT(*) as cantidad FROM notas WHERE activo = 1 GROUP BY estadoNota");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo "<li>{$row['estadoNota']}: {$row['cantidad']}</li>";
                        }
                        ?>
                    </ul>
                    <p class="text-primary">Inactivas: 
                        <?php
                        $stmt = $con->query("SELECT COUNT(*) as cantidad FROM notas WHERE activo = 0");
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo $row['cantidad'];
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>