<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['proyecto_id'])) {
    $proyectoId = $_GET['proyecto_id'];
} else {
    die('No se ha especificado un ID de proyecto.');
}

$dniUsuario = $_SESSION["dni"];
$rolUsuario = isset($_SESSION["rol"]) ? $_SESSION["rol"] : "invitado";

$PAGS = 5;
$pagina = isset($_GET["pagina"]) ? $_GET["pagina"] : 1;
$inicio = ($pagina - 1) * $PAGS;

$orden = isset($_GET['orden']) ? $_GET['orden'] : 'asc';

try {
    // Obtener el nombre del proyecto
    $stmtProyecto = $con->prepare("SELECT nombreProyecto FROM proyectos WHERE id = :proyectoId");
    $stmtProyecto->bindParam(':proyectoId', $proyectoId, PDO::PARAM_INT);
    $stmtProyecto->execute();
    $proyecto = $stmtProyecto->fetch(PDO::FETCH_ASSOC);
    if (!$proyecto) {
        die('Proyecto no encontrado.');
    }
    $nombreProyecto = $proyecto['nombreProyecto'];

    $sql = "SELECT DISTINCT t.*, u.nombre AS nombreUsuario FROM tareas t 
            JOIN usuarios u ON t.dniUsuario = u.dni 
            LEFT JOIN tareas_usuarios tu ON t.id = tu.tarea_id 
            WHERE t.proyecto_id = :proyectoId ";

    if ($rolUsuario == "Administrador") {
        // Los administradores pueden ver todas las tareas, incluidas las eliminadas
        $sql .= "AND (t.activo = 0 OR t.activo = 1) ";
    } elseif ($rolUsuario == "Jefe") {
        // Los jefes solo pueden ver tareas activas que han creado o que les han sido asignadas
        $sql .= "AND t.activo = 1 AND (t.dniUsuario = :dniUsuario OR tu.dniUsuario = :dniUsuario) ";
    } else {
        // Otros usuarios solo pueden ver tareas activas que les han sido asignadas
        $sql .= "AND t.activo = 1 AND tu.dniUsuario = :dniUsuario ";
    }

    // Agregar término de búsqueda a la consulta SQL
    if (!empty($busqueda)) {
        $sql .= "AND (t.nombreTarea LIKE :busqueda OR t.estadoTarea LIKE :busqueda OR u.nombre LIKE :busqueda) ";
        $params[":busqueda"] = '%' . $busqueda . '%';
    }

    $sql .= "ORDER BY t.nombreTarea $orden LIMIT :inicio, :PAGS";

    $stmt = $con->prepare($sql);
    $stmt->bindParam(':proyectoId', $proyectoId, PDO::PARAM_INT);
    $stmt->bindParam(':inicio', $inicio, PDO::PARAM_INT);
    $stmt->bindParam(':PAGS', $PAGS, PDO::PARAM_INT);

    if ($rolUsuario != "Administrador") {
        $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);
    }

    $stmt->execute();
    $tareas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmtCount = $con->prepare("SELECT COUNT(*) as total FROM tareas WHERE proyecto_id = :proyectoId");
    $stmtCount->bindParam(':proyectoId', $proyectoId, PDO::PARAM_INT);
    $stmtCount->execute();
    $totalTareas = $stmtCount->fetch(PDO::FETCH_ASSOC)['total'];
    $totalPaginas = ceil($totalTareas / $PAGS);
} catch (PDOException $e) {
    $jsAlert = "alert('Error: " . $e->getMessage() . "');";
    $redirect = "window.location.href = 'index.php';";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Tareas</h2>
        <a href="mostrarProyectos.php" class="btn btn-primary text-light">Volver</a>
    </div>
    <div class="mb-3 text-primary">
        <h3><?= htmlspecialchars($nombreProyecto) ?></h3>
    </div>
    <div class="table-container">
        <table class="table table-responsive align-middle text-center">
        <caption class="d-none">Tabla de tareas</caption>
        <thead class="table-primary" style="font-size: 15px;">
            <tr>
                <?php if ($rolUsuario == "Administrador") : ?>
                    <th scope="col">Activo</th>
                <?php endif; ?>
                <th scope="col">Nombre</th>
                <th scope="col">Estado</th>
                <th scope="col">Fecha Fin Prevista</th>
                <th scope='col'>Consultar</th>
                <th scope='col'>Ver Notas</th>
                <th scope='col'>Crear Nota</th>
                <th scope='col'>Editar</th>
                <?php if ($rolUsuario == "Administrador" || $rolUsuario == "Jefe") : ?>
                    <th scope='col'>Cancelar</th>
                    <th scope='col'>Asignar Usuario</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody style="font-size: 15px;">
            <?php foreach ($tareas as $tarea) : ?>
                <?php
                // Calcula la fecha actual y la fecha límite para la tarea
                $fechaActual = strtotime(date("Y-m-d"));
                $fechaLimite = strtotime($tarea['fechaFinalizacionPrevista']);
                
                // Calcula la diferencia en días entre las fechas
                $diferenciaDias = round(($fechaLimite - $fechaActual) / (60 * 60 * 24));
                
                // Determina si faltan tres días o menos para la entrega de la tarea
                $claseFecha = ($diferenciaDias <= 2) ? 'bg-danger text-light' : '';
                ?>
                <tr>
                    <?php if ($rolUsuario == "Administrador") : ?>
                        <td><?= $tarea['activo'] ? 'Sí' : 'No' ?></td>
                    <?php endif; ?>
                    <td><?= htmlspecialchars($tarea['nombreTarea']) ?></td>
                    <?php 
                    $textoClase = strtolower($tarea['estadoTarea']) === 'finalizada'? 'bg-success text-light' : '';
                    ?>
                    <td class="<?= $textoClase ?>"><?= htmlspecialchars($tarea['estadoTarea']) ?></td>
                    <td class="<?= $claseFecha ?>"><?= $tarea['fechaFinalizacionPrevista'] ?></td>
                    <td><a href="verTarea.php?id=<?= $tarea['id'] ?>&proyecto_id=<?= $proyectoId ?>"><img src='imags/ver.png' alt='Ver' style='width: 50px; height: 50px;'></a></td>
                    <td><a href='mostrarNotas.php?tarea_id=<?= $tarea['id'] ?>&proyecto_id=<?= $proyectoId ?>'><img src='imags/vernota.png' alt='Ver Notas' style='width: 50px; height: 50px;'></a></td>
                    <td><a href='nuevaNota.php?tarea_id=<?=$tarea['id'] ?>&proyecto_id=<?= $proyectoId ?>'><img src='imags/nota.png' alt='Crear Nota' style='width: 50px; height: 50px;'></a></td>
                    <td><a href="editarTarea.php?id=<?= $tarea['id'] ?>&proyecto_id=<?= $proyectoId ?>"><img src='imags/editar.png' alt='Editar' style='width: 50px; height: 50px;'></a></td>
                    <?php if ($rolUsuario == "Administrador" || $rolUsuario == "Jefe") : ?>
                    <td><a href="borrarTarea.php?id=<?= $tarea['id'] ?>&proyecto_id=<?= $proyectoId ?>"><img src='imags/cancelar.png' alt='Cancelar' style='width: 50px; height: 50px;'></a></td>
                    <td><a href='asignarUsuarioATarea.php?id=<?= $tarea['id'] ?>'><img src='imags/usuario.png' alt='Asignar Usuario' style='width: 50px; height: 50px;'></a></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
        </table>
    </div>

    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <?php if ($pagina > 1) : ?>
                <li class="page-item">
                    <a class="page-link" href="?proyecto_id=<?= $proyectoId ?>&pagina=<?= ($pagina - 1) ?>&orden=<?= $orden ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only"></span>
                    </a>
                </li>
            <?php endif; ?>

            <?php
            $inicioPaginas = max(1, $pagina - 2);
            $finPaginas = min($totalPaginas, $pagina + 2);

            for ($i = $inicioPaginas; $i <= $finPaginas; $i++) :
            ?>
                <li class="page-item <?= $pagina == $i ? 'active' : '' ?>">
                    <a class="page-link" href="?proyecto_id=<?= $proyectoId ?>&pagina=<?= $i ?>&orden=<?= $orden ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($pagina < $totalPaginas) : ?>
                <li class="page-item">
                    <a class="page-link" href="?proyecto_id=<?= $proyectoId ?>&pagina=<?= ($pagina + 1) ?>&orden=<?= $orden ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only"></span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <br>
    <a href="?proyecto_id=<?= $proyectoId ?>&orden=asc" class="text-decoration-none text-primary <?= $orden == 'asc' ? 'selected' : '' ?>">Nombre Asc | </a>
    <a href="?proyecto_id=<?= $proyectoId ?>&orden=desc" class="text-decoration-none text-primary <?= $orden == 'desc' ? 'selected' : '' ?>">Nombre Desc</a><br><br>
</main>

<?php
include "footer.php";
$con = null;
?>