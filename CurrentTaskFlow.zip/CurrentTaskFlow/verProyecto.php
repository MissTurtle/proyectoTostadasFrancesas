<?php
session_start();
include "funciones.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];

try {
    // Obtener información del proyecto
    $stmt = $con->prepare("SELECT * FROM proyectos WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $proyecto = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$proyecto) {
        echo "<script>alert('Proyecto no encontrado.'); window.location.href = 'buscarProyecto.php';</script>";
        exit();
    }

    // Obtener el nombre del creador del proyecto
    $stmt = $con->prepare("SELECT nombre FROM usuarios WHERE dni = :dniUsuario");
    $stmt->bindParam(':dniUsuario', $proyecto['dniUsuario'], PDO::PARAM_STR);
    $stmt->execute();
    $creador_proyecto = $stmt->fetch(PDO::FETCH_COLUMN);

    // Mensaje si el creador no está disponible
    $nombre_creador = $creador_proyecto ? htmlspecialchars($creador_proyecto) : "No disponible";

    // Obtener los nombres de los usuarios asignados al proyecto
    $stmt = $con->prepare("SELECT u.nombre FROM proyectos_usuarios pu JOIN usuarios u ON pu.dniUsuario = u.dni WHERE pu.proyecto_id = :proyecto_id");
    $stmt->bindParam(':proyecto_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $usuarios_asignados = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Mensaje si no hay usuarios asignados
    $mensaje_usuarios = empty($usuarios_asignados) ? "No hay usuarios asignados al proyecto" : "<ul><li>" . implode('</li><li>', $usuarios_asignados) . "</li></ul>";

} catch (PDOException $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'index.php';</script>";
    exit();
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Información del proyecto</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <div class="row mt-3 mb-3">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-text">Nombre del Proyecto: <?php echo htmlspecialchars($proyecto['nombreProyecto']); ?></h5><br>
                    <h6 class="card-text">Descripción: <?php echo htmlspecialchars($proyecto['descripcionProyecto']); ?></h6><br>
                    <p class="card-text">Repositorio del proyecto: 
                    <?php 
                        if (!empty($proyecto['repositorio'])) {
                            echo '<a href="' . htmlspecialchars($proyecto['repositorio']) . '" target="_blank">' . htmlspecialchars($proyecto['repositorio']) . '</a>';
                        } else {
                            echo 'No disponible';
                        }
                    ?>
                    </p>
                    <p class="card-text">Usuarios asignados al proyecto: <?php echo $mensaje_usuarios; ?></p>
                    <p class="card-text">Fecha de Creación: <?php echo htmlspecialchars($proyecto['fechaCreacion']); ?></p>
                    <p class="card-text">Fecha de Finalización Prevista: <?php echo htmlspecialchars($proyecto['fechaFinalizacionPrevista']); ?></p>
                    <p class="card-text">Estado del Proyecto: <?php echo htmlspecialchars($proyecto['estadoProyecto']); ?></p>
                    <p class="card-text">Jefe de proyecto: <?php echo $nombre_creador; ?></p>
                    <p class="card-text">Activo: <?php echo $proyecto['activo'] ? "Sí" : "No"; ?></p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>