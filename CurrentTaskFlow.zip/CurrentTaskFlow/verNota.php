<?php
session_start();
include "funciones.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];

// Obtener información de la nota
try {
    $stmt = $con->prepare("SELECT * FROM notas WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $nota = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$nota) {
        echo "<script>alert('Nota no encontrada.'); window.location.href = 'buscarNota.php';</script>";
        exit();
    }

    // Obtener el nombre del proyecto
    $nombre_proyecto = '';
    $proyectoId = null;
    if ($nota['proyecto_id']) {
        $proyectoId = $nota['proyecto_id'];
        $stmt = $con->prepare("SELECT nombreProyecto FROM proyectos WHERE id = :proyecto_id");
        $stmt->bindParam(':proyecto_id', $proyectoId, PDO::PARAM_INT);
        $stmt->execute();
        $proyecto = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($proyecto) {
            $nombre_proyecto = $proyecto['nombreProyecto'];
        }
    }

    // Obtener el nombre de la tarea
    $nombre_tarea = '';
    $tareaId = null;
    if ($nota['tarea_id']) {
        $tareaId = $nota['tarea_id'];
        $stmt = $con->prepare("SELECT nombreTarea FROM tareas WHERE id = :tarea_id");
        $stmt->bindParam(':tarea_id', $tareaId, PDO::PARAM_INT);
        $stmt->execute();
        $tarea = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($tarea) {
            $nombre_tarea = $tarea['nombreTarea'];
        }
    }

    // Obtener el nombre del creador de la nota
    $stmt = $con->prepare("SELECT nombre FROM usuarios WHERE dni = :dniUsuario");
    $stmt->bindParam(':dniUsuario', $nota['dniUsuario'], PDO::PARAM_STR);
    $stmt->execute();
    $creador_nombre = $stmt->fetch(PDO::FETCH_ASSOC)['nombre'];

} catch (PDOException $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'index.php';</script>";
    exit();
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Información de la nota</h2>
        <a href="<?= isset($tareaId) ? 'mostrarNotas.php?proyecto_id=' . $proyectoId . '&tarea_id=' . $tareaId : 'mostrarNotas.php' ?>" class="btn btn-primary text-light">Volver</a>
    </div>
    <div class="row mt-3 mb-3">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-text">Nombre de la Nota: <?php echo htmlspecialchars($nota['nombreNota']); ?></h5><br>
                    <h6 class="card-text">Reporte: <?php echo htmlspecialchars($nota['contenido']); ?></h6><br>
                    <p>Evidencia: 
                        <?php if ($nota['evidencia']) : ?>
                            <a href="#" onclick="verImagen('<?php echo $nota['evidencia']; ?>')">Ver</a>
                        <?php else : ?>
                            -
                        <?php endif; ?>
                    </p>
                    <p class="card-text">Fecha de Creación: <?php echo htmlspecialchars($nota['fechaCreacion']); ?></p>
                    <?php if (!empty($nombre_proyecto)) : ?>
                        <p class="card-text">Proyecto: <?php echo htmlspecialchars($nombre_proyecto); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($nombre_tarea)) : ?>
                        <p class="card-text">Tarea: <?php echo htmlspecialchars($nombre_tarea); ?></p>
                    <?php endif; ?>
                    <p class="card-text">Estado de la Nota: <?php echo htmlspecialchars($nota['estadoNota']); ?></p>
                    <p class="card-text">Creador: <?php echo htmlspecialchars($creador_nombre); ?></p>
                    <p class="card-text">Activa: <?php echo $nota['activo'] ? "Sí" : "No"; ?></p>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    function verImagen(urlImagen) {
        window.open(urlImagen, 'imagenPopup', 'width=500,height=500');
    }
</script>

<?php
include "footer.php";
$con = null;
?>