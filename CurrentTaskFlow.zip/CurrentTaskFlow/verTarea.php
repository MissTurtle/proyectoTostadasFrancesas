<?php
session_start();
include "funciones.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];

// Obtener información de la tarea
try {
    $stmt = $con->prepare("SELECT * FROM tareas WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $tarea = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tarea) {
        echo "<script>alert('Tarea no encontrada.'); window.location.href = 'buscarTarea.php';</script>";
        exit();
    }

    // Obtener el nombre del proyecto
    $stmt = $con->prepare("SELECT nombreProyecto FROM proyectos WHERE id = :proyecto_id");
    $stmt->bindParam(':proyecto_id', $tarea['proyecto_id'], PDO::PARAM_INT);
    $stmt->execute();
    $proyecto = $stmt->fetch(PDO::FETCH_ASSOC);

    // Obtener el nombre del usuario asignado a la tarea
    $stmt = $con->prepare("SELECT u.nombre FROM tareas_usuarios tu JOIN usuarios u ON tu.dniUsuario = u.dni WHERE tu.tarea_id = :tarea_id");
    $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $tarea_usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    $usuario_nombre = '';
    if ($tarea_usuario) {
        $usuario_nombre = $tarea_usuario['nombre'];
    } else {
        $usuario_nombre = "No hay ningún usuario que tenga asignada esta tarea";
    }

    // Obtener el nombre del creador de la tarea
    $stmt = $con->prepare("SELECT nombre FROM usuarios WHERE dni = :dniUsuario");
    $stmt->bindParam(':dniUsuario', $tarea['dniUsuario'], PDO::PARAM_STR);
    $stmt->execute();
    $creador = $stmt->fetch(PDO::FETCH_ASSOC)['nombre'];

} catch (PDOException $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'index.php';</script>";
    exit();
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Información de la tarea</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <div class="row mt-3 mb-3">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-text">Nombre de la Tarea: <?php echo htmlspecialchars($tarea['nombreTarea']); ?></h5><br>
                    <h6 class="card-text">Descripción: <?php echo htmlspecialchars($tarea['descripcionTarea']); ?></h6><br>
                    <p class="card-text">Proyecto: <?php echo htmlspecialchars($proyecto['nombreProyecto']); ?></p>
                    <p class="card-text">Usuario al que está asignada: <?php echo htmlspecialchars($usuario_nombre); ?></p>
                    <p class="card-text">Fecha de Creacion: <?php echo htmlspecialchars($tarea['fechaCreacion']); ?></p>
                    <p class="card-text">Fecha de Finalización Prevista: <?php echo htmlspecialchars($tarea['fechaFinalizacionPrevista']); ?></p>
                    <p class="card-text">Estado de la Tarea: <?php echo htmlspecialchars($tarea['estadoTarea']); ?></p>
                    <p class="card-text">Creador: <?php echo htmlspecialchars($creador); ?></p>
                    <p class="card-text">Activa: <?php echo $tarea['activo'] ? "Sí" : "No"; ?></p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>