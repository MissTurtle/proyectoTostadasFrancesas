<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    try {
        // Consulta SQL para obtener los datos de la nota
        $sql = "SELECT * FROM notas WHERE id = :id";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        // Guardar la fila de la nota
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fila) {
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirmar"])) {
                // Actualizar el campo "activo" a 0 en lugar de borrar la nota
                $sqlActualizar = "UPDATE notas SET activo = 0 WHERE id = :id";
                $stmtActualizar = $con->prepare($sqlActualizar);
                $stmtActualizar->bindParam(":id", $id, PDO::PARAM_INT);

                if ($stmtActualizar->execute()) {
                    $jsAlert = "alert('La nota ha sido borrada.');";
                    // Redirigir a mostrarNotas.php después de borrar la nota
                    $redirect = "mostrarNotas.php";
                    if (isset($_GET["proyecto_id"])) {
                        $redirect .= "?proyecto_id=" . $_GET["proyecto_id"];
                        if (isset($_GET["tarea_id"])) {
                            $redirect .= "&tarea_id=" . $_GET["tarea_id"];
                        } else {
                            $redirect .= "&tarea_id=null";
                        }
                    }
                } else {
                    throw new Exception("Error al cancelar la nota.");
                }
            }
        } else {
            // Si la nota no existe, redirecciona
            throw new Exception("Nota no encontrada.");
        }
    } catch (Exception $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "mostrarNotas.php";
    }
} else {
    $redirect = "mostrarNotas.php";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert window.location.href = '$redirect';</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Borrar nota</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <?php if (isset($fila)): ?>
    <p>¿Seguro que quieres borrar la nota <?php echo $fila["nombreNota"]; ?>??</p>
    <form name="formconf" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
        </div>
        <div class="mb-3">
            <input type="submit" class="btn btn-primary text-light" name="confirmar" value="Confirmar"><br>
        </div>
    </form>
    <?php else: ?>
    <p>Nota no encontrada.</p>
    <?php endif; ?>
</main>

<?php
include "footer.php";
$con = null;
?>