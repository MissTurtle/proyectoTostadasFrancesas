        </div>
            <div class="col-xs-12 col-sm-4 col-md-2 bg-light-blue text-dark">
                <aside class="container-fluid pe-4">
                    <div>
                    <?php
                    // Verifica si el usuario está autenticado
                    if (isset($_SESSION["dni"])) {
                        echo '<h3 class="text-dark">¡Hola <strong class="text-dark">' . $_SESSION["usuario"]["nombre"] . '</strong>!</h3><br>';
                        // Muestra el menú solo si el usuario está autenticado
                        echo '
                        <div>
                        <nav>
                        <ul class="list-unstyled">
                            <li>
                                <form action="logout.php" method="POST" style="display: inline;">
                                    <input type="submit" class="btn btn-dark text-light" value="Cerrar sesión">
                                </form>
                            </li><br><br>
                            <li><a class="nav-link text-decoration-none text-dark" href="index.php">Inicio</a></li><br><br>
                            <li><a class="nav-link text-decoration-none text-dark" href="mostrarUsuarios.php">Gestión de Usuarios</a></li><br>
                            <li><a class="nav-link text-decoration-none text-dark" href="mostrarProyectos.php">Gestión de Proyectos</a></li><br>
                            <li><a class="nav-link text-decoration-none text-dark" href="estadisticas.php">Estadísticas</a></li><br>
                        </ul>
                        </nav>
                        </div>';
                    } else {
                        // Muestra el formulario de inicio de sesión si el usuario no está autenticado
                        echo '
                        <h2>Inicia sesión</h2>
                        <form name="log" method="POST" enctype="multipart/form-data" action="login.php">
                            <div class="mb-3">
                                <label for="dni" class="form-label">DNI</label>
                                <input type="text" class="form-control" name="dni" maxlength="9" required>
                            </div>
                            <div class="mb-3">
                                <label for="contrasenya" class="form-label">Contraseña</label>
                                <input type="password" class="form-control" name="contrasenya" maxlength="9" required>
                            </div>
                            <div class="mb-3">
                                <input type="submit" class="btn btn-dark text-light" value="Iniciar Sesión"><br><br>
                            </div>
                        </form>
                        <a class="text-decoration-none text-dark" href="nuevoRegistro.php">Regístrate ahora</a><br><br>
                        <a class="text-decoration-none text-dark" href="olvideContrasenya.php">He olvidado mi contraseña</a>';
                    }
                    ?>
                    </div>
                </aside>
            </div>
        </div>
        <footer class="bg-light-blue" id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 pt-3">
                        <h2 class="pb-3 border-light">CurrentTaskFlow</h2>
                    </div>
                    <div class="col-md-4 pt-3">
                        <h2 class="pb-3 text-primary border-bottom border-primary">Tus Posibilidades</h2>
                            <ul class="list-unstyled">
                                <li class="text-primary">Crea proyectos</li>
                                <li class="text-primary">Divide tus proyectos en tareas</li>
                                <li class="text-primary">Asigna tareas a tus empleados</li>
                                <li class="text-primary">Lleva un seguimiento de los avances</li>
                            </ul>
                    </div>
                    <div class="col-md-4 pt-3">
                        <h2 class="pb-3 text-primary border-bottom border-primary">Empresa</h2>
                            <ul class="list-unstyled">
                                <li><a class="text-decoration-none text-primary" href="index.php">Inicio</a></li>
                                <li><a class="text-decoration-none text-primary" href="quienesSomos.php">Quiénes somos</a></li>
                                <li><a class="text-decoration-none text-primary" href="politicaPrivacidad.php">Política de privacidad</a></li>
                                <li><a class="text-decoration-none text-primary" href="contacto.php">Contacto</a></li>
                            </ul>
                    </div>
                </div>
            </div>
            <div class="w-100 bg-dark py-2">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                        <p class="text-left text-primary">Copyright &copy; 2024 CurrentTaskFlow</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>