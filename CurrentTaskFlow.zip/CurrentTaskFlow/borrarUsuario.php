<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

// Obtener el rol del usuario que ha iniciado sesión
$rolUsuario = isset($_SESSION["rol"]) ? $_SESSION["rol"] : "";

// Obtener el DNI del usuario que se quiere dar de baja
if (isset($_GET["dni"])) {
    $dni = $_GET["dni"];

    try {
        // Consulta SQL para obtener los datos del usuario
        $sql = "SELECT * FROM usuarios WHERE dni = :dni";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":dni", $dni);
        $stmt->execute();

        // Guardar la fila del usuario
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fila) {
            // Si se ha confirmado la baja del usuario
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirmar"])) {
                // Verificar si el usuario administrador intenta darse de baja
                if ($_SESSION["rol"] == "Administrador" && $_SESSION["dni"] == $dni) {
                    $jsAlert = "alert('No puedes darte de baja porque eres administrador.');";
                    $redirect = "window.location.href = 'mostrarUsuarios.php';";
                } else {
                    try {
                        $con->beginTransaction();

                        // Eliminar las relaciones en la tabla tareas_usuarios asociadas al usuario que se está desactivando
                        $sqlEliminarTareas = "DELETE FROM tareas_usuarios WHERE dniUsuario = :dni";
                        $stmtEliminarTareas = $con->prepare($sqlEliminarTareas);
                        $stmtEliminarTareas->bindParam(":dni", $dni);
                        $stmtEliminarTareas->execute();

                        // Eliminar las relaciones en la tabla proyectos_usuarios asociadas al usuario que se está desactivando
                        $sqlEliminarProyectos = "DELETE FROM proyectos_usuarios WHERE dniUsuario = :dni";
                        $stmtEliminarProyectos = $con->prepare($sqlEliminarProyectos);
                        $stmtEliminarProyectos->bindParam(":dni", $dni);
                        $stmtEliminarProyectos->execute();

                        // Actualizar el campo "activo" a 0 en lugar de borrar al usuario
                        $sqlActualizar = "UPDATE usuarios SET activo = 0 WHERE dni = :dni";
                        $stmtActualizar = $con->prepare($sqlActualizar);
                        $stmtActualizar->bindParam(":dni", $dni);
                        $stmtActualizar->execute();

                        $con->commit();

                        // Verificar si el usuario que se da de baja es el mismo que inició sesión
                        if ($_SESSION['dni'] == $dni) {
                            // Cerrar la sesión y redirigir al login
                            session_unset();
                            session_destroy();
                            $jsAlert = "alert('Te has dado de baja.');";
                            $redirect = "window.location.href = 'index.php';";
                        } else {
                            // Redirigir a la página de usuarios
                            $jsAlert = "alert('El usuario " . $fila["nombre"] . " ha sido dado de baja.');";
                            $redirect = "window.location.href = 'mostrarUsuarios.php';";
                        }
                    } catch (PDOException $e) {
                        $con->rollBack();
                        $jsAlert = "alert('Error al dar de baja al usuario.');";
                        $redirect = "window.location.href = 'mostrarUsuarios.php';";
                    }
                }
            }
        }
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarUsuarios.php';";
    }
} else {
    $redirect = "window.location.href = 'mostrarUsuarios.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Dar de baja usuario</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <p>¿Seguro que quieres dar de baja al usuario <?php echo $fila["nombre"]; ?>?</p>
    <form name="formconf" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
        <input type="hidden" class="form-control" name="dni" value="<?php echo $dni; ?>">
        </div>
        <div class="mb-3">
        <input type="submit" class="btn btn-primary text-light" name="confirmar" value="Confirmar"><br>
        </div>
    </form>
</main>

<?php
include "footer.php";
$con = null;
?>