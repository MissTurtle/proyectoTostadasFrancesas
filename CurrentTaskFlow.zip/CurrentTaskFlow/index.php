<?php
session_start();
include "funciones.php";
include "header.php";

$PAGS = 4;
$pagina = 1;
$inicio = 0;

if(isset($_GET["pagina"])){
    $pagina = $_GET["pagina"];
    $inicio = ($pagina - 1) * $PAGS;
}

$ordenarPor = isset($_GET["ordenarPor"]) ? $_GET["ordenarPor"] : "nombre";
$orden = isset($_GET["orden"]) ? $_GET["orden"] : "asc";

?>

<main class="container">
    <div class="row">
        <div class="col">
            <h2 class="text-center mt-3">Bienvenido/a a CurrentTaskFlow</h2>
            <p class="lead text-center text-primary">Aquí podrás gestionar tus proyectos de manera eficiente y colaborativa.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mt-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Administra tus Proyectos</h3>
                    <p class="card-text text-primary">Crea y edita proyectos de manera sencilla.</p>
                    <p class="card-text text-primary">Establece fechas de inicio y finalización, y sigue el progreso de tus proyectos en tiempo real.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mt-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Crea Tareas y Notas</h3>
                    <p class="card-text text-primary">Crea tareas para organizar el trabajo.</p>
                    <p class="card-text text-primary">Haz anotaciones para tus proyectos y tareas con el contenido que quieras.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6 mt-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Trabaja en Equipo</h3>
                    <p class="card-text text-primary">Invita a otros miembros de tu equipo a colaborar en tus proyectos.</p>
                    <p class="card-text text-primary">Asigna tareas y comunícate de manera efectiva para lograr los objetivos establecidos.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mt-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Visualiza tus Estadísticas</h3>
                    <p class="card-text text-primary">Obten información sobre el estado de tus proyectos y tareas.</p>
                    <p class="card-text text-primary">Visualiza dato que te ayudarán a tomar decisiones informadas y mejorar la productividad de tu equipo.</p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>