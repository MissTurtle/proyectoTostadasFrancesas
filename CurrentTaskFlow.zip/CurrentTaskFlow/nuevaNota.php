<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreNota = $_POST["nombreNota"];
    $contenido = $_POST["contenido"];
    $activo = isset($_POST["activo"]) ? 1 : 0;
    $dniUsuario = $_SESSION["dni"];
    $proyecto_id = isset($_POST["proyecto_id"]) ? $_POST["proyecto_id"] : null;
    $tarea_id = isset($_POST["tarea_id"]) ? $_POST["tarea_id"] : null;
    $estadoNota = isset($_POST["estadoNota"]) ? $_POST["estadoNota"] : "Pendiente";
    $fechaCreacion = date("Y-m-d H:i:s");
    $evidenciaPath = null;

    if (isset($_FILES["evidencia"]) && $_FILES["evidencia"]["error"] == 0) {
        $targetDir = "Descargas/";
        $fileName = uniqid() . "_" . basename($_FILES["evidencia"]["name"]); // Generar un nombre único
        $evidenciaPath = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["evidencia"]["tmp_name"], $evidenciaPath)) {
        } else {
            $jsAlert = "alert('Error al subir la evidencia.');";
        }
    }

    try {
        $query = "INSERT INTO notas (nombreNota, contenido, fechaCreacion, activo, dniUsuario, proyecto_id, tarea_id, estadoNota, evidencia) VALUES (:nombreNota, :contenido, :fechaCreacion, :activo, :dniUsuario, :proyecto_id, :tarea_id, :estadoNota, :evidencia)";
        $stmt = $con->prepare($query);

        $stmt->bindParam(':nombreNota', $nombreNota, PDO::PARAM_STR);
        $stmt->bindParam(':contenido', $contenido, PDO::PARAM_STR);
        $stmt->bindParam(':fechaCreacion', $fechaCreacion, PDO::PARAM_STR);
        $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
        $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);
        $stmt->bindParam(':proyecto_id', $proyecto_id, PDO::PARAM_INT);
        $stmt->bindParam(':tarea_id', $tarea_id, PDO::PARAM_INT);
        $stmt->bindParam(':estadoNota', $estadoNota, PDO::PARAM_STR);
        $stmt->bindParam(':evidencia', $evidenciaPath, PDO::PARAM_STR);

        $stmt->execute();

        if ($proyecto_id !== null && $tarea_id !== null) {
            $redirect = "mostrarTareas.php?proyecto_id=$proyecto_id";
        } else {
            $redirect = "mostrarProyectos.php";
        }
        $jsAlert = "alert('Nota agregada con éxito.');";
    } catch (PDOException $e) {
        $jsAlert = "alert('Error al agregar la nota: " . $e->getMessage() . "');";
        if ($proyecto_id !== null) {
            $redirect = "nuevaNota.php?proyecto_id=$proyecto_id";
        } elseif ($tarea_id !== null) {
            $redirect = "nuevaNota.php?tarea_id=$tarea_id";
        }
    }
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert; window.location.href = '$redirect';</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Crea una nueva nota</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formnpro" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nombreNota" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombreNota" required>
        </div>
        <div class="mb-3">
            <label for="contenido" class="form-label">Reporte:</label>
            <textarea class="form-control w-25" name="contenido" required></textarea>
        </div>
        <div class="mb-3">
            <label for="evidencia" class="form-label">Evidencia:</label>
            <input type="file" class="form-control w-25" name="evidencia" accept="image/*">
        </div>
        <div class="mb-3">
            <label for="estadoNota" class="form-label">Estado de la Nota:</label>
            <select name="estadoNota" required>
                <option value="Pendiente">Pendiente</option>
                <option value="Iniciada">Iniciada</option>
                <option value="En revisión">En revisión</option>
                <option value="Finalizada">Finalizada</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" checked>
        </div>
        <?php
        $proyecto_id = isset($_GET['proyecto_id']) ? $_GET['proyecto_id'] : null;
        $tarea_id = isset($_GET['tarea_id']) ? $_GET['tarea_id'] : null;
        ?>

        <?php if ($proyecto_id !== null) : ?>
            <input type="hidden" name="proyecto_id" value="<?= $proyecto_id ?>">
        <?php endif; ?>

        <?php if ($tarea_id !== null) : ?>
            <input type="hidden" name="tarea_id" value="<?= $tarea_id ?>">
        <?php endif; ?>
        <div class="mb-3">
            <input type="reset" class="btn btn-primary text-light" name="Borrar" value="Borrar datos">
            <input type="submit" class="btn btn-primary text-light" name="Enviar" value="Enviar datos"><br><br>
        </div>
    </form>
</main>

<?php
include "footer.php";
$con = null;
?>