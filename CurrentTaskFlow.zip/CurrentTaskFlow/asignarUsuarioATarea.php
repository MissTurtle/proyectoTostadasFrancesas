<?php
session_start();
include "funciones.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];

// Obtener lista de usuarios activos y asignados a la tarea
try {
    $stmt = $con->prepare("SELECT u.dni, u.nombre, u.rol 
                           FROM usuarios u 
                           INNER JOIN tareas_usuarios tu ON u.dni = tu.dniUsuario 
                           WHERE u.activo = 1 AND tu.tarea_id = :tarea_id");
    $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $usuariosAsignados = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'index.php';</script>";
    exit();
}

// Obtener lista de usuarios activos y no asignados a la tarea
try {
    $stmt = $con->prepare("SELECT u.dni, u.nombre, u.rol 
                           FROM usuarios u 
                           INNER JOIN proyectos_usuarios pu ON u.dni = pu.dniUsuario 
                           INNER JOIN tareas t ON t.proyecto_id = pu.proyecto_id
                           WHERE u.activo = 1 AND t.id = :tarea_id
                           AND u.dni NOT IN (SELECT dniUsuario FROM tareas_usuarios WHERE tarea_id = :tarea_id)");
    $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'index.php';</script>";
    exit();
}

// Asignar usuario a la tarea
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dniUsuario'])) {
    if (count($usuariosAsignados) > 0) {
        echo "<script>alert('Error: Ya hay un usuario asignado a esta tarea.'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
        exit();
    }

    $dniUsuario = $_POST['dniUsuario'];

    // Obtener proyecto_id de la tarea
    try {
        $stmt = $con->prepare("SELECT proyecto_id FROM tareas WHERE id = :tarea_id");
        $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $proyecto_id = $row['proyecto_id'];
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
        exit();
    }

    try {
        $stmt = $con->prepare("INSERT INTO tareas_usuarios (tarea_id, proyecto_id, dniUsuario) VALUES (:tarea_id, :proyecto_id, :dniUsuario)");
        $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':proyecto_id', $proyecto_id, PDO::PARAM_INT);
        $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);
        $stmt->execute();
        echo "<script>alert('Usuario asignado con éxito.'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
        exit();
    }
}

// Desasignar usuario de la tarea
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dniUsuarioDesasignar'])) {
    $dniUsuarioDesasignar = $_POST['dniUsuarioDesasignar'];

    try {
        $stmt = $con->prepare("DELETE FROM tareas_usuarios WHERE tarea_id = :tarea_id AND dniUsuario = :dniUsuario");
        $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':dniUsuario', $dniUsuarioDesasignar, PDO::PARAM_STR);
        $stmt->execute();
        echo "<script>alert('Usuario desasignado con éxito.'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
        exit();
    }
}

include "header.php";

// Obtener proyecto_id de la tarea
try {
    $stmt = $con->prepare("SELECT proyecto_id FROM tareas WHERE id = :tarea_id");
    $stmt->bindParam(':tarea_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $proyectoId = $row['proyecto_id'];
} catch (PDOException $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'asignarUsuarioATarea.php?id=$id';</script>";
    exit();
}
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Asignar a un Usuario</h2>
        <a href="mostrarTareas.php?proyecto_id=<?= $proyectoId ?>" class="btn btn-primary text-light">Volver</a>
    </div>
    <h4 class="card-title">Usuario asignado a la Tarea</h4><br>
        <form method="POST" action="asignarUsuarioATarea.php?id=<?= $id ?>">
            <div class="form-group">
                <select class="form-control w-25" id="dniUsuarioDesasignar" name="dniUsuarioDesasignar" required>
                    <?php if (empty($usuariosAsignados)): ?>
                        <option value="">No hay usuarios asignados</option>
                    <?php else: ?>
                        <option value="" disabled selected>Seleccione un usuario</option>
                        <?php foreach ($usuariosAsignados as $usuarioAsignado): ?>
                            <option value="<?php echo htmlspecialchars($usuarioAsignado['dni']); ?>">
                                <?php echo htmlspecialchars($usuarioAsignado['nombre'] . " (" . $usuarioAsignado['rol'] . ")"); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <br><button type="submit" class="btn btn-danger text-light" <?php echo empty($usuariosAsignados) ? 'disabled' : ''; ?>>Desasignar</button><br><br>
        </form>
        <h4 class="card-title">Usuarios disponibles para asignar a la Tarea</h4><br>
        <form method="POST" action="asignarUsuarioATarea.php?id=<?= $id ?>">
            <div class="form-group">
                <select class="form-control w-25" id="dniUsuario" name="dniUsuario" required>
                    <?php if (empty($usuarios)): ?>
                        <option value="">No hay usuarios disponibles para asignar</option>
                    <?php else: ?>
                        <option value="" disabled selected>Seleccione un usuario</option>
                        <?php foreach ($usuarios as $usuario): ?>
                            <option value="<?php echo htmlspecialchars($usuario['dni']); ?>">
                                <?php echo htmlspecialchars($usuario['nombre'] . " (" . $usuario['rol'] . ")"); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <br><button type="submit" class="btn btn-primary text-light" <?php echo empty($usuarios) ? 'disabled' : ''; ?>>Asignar</button><br><br>
        </form>
</main>

<?php
include "footer.php";
$con = null;
?>