<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

// Obtener el rol del usuario que ha iniciado sesión
$rolUsuario = isset($_SESSION["rol"]) ? $_SESSION["rol"] : "invitado";
$dniUsuario = $_SESSION["dni"];

$PAGS = 5;
$pagina = 1;
$inicio = 0;

if (isset($_GET["pagina"])) {
    $pagina = $_GET["pagina"];
    $inicio = ($pagina - 1) * $PAGS;
}

$orden = isset($_GET['orden']) ? $_GET['orden'] : 'asc';

// Obtengo el término de búsqueda
$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';

$params = [];
$sql = "";

try {
    // Consulta
    $sql = "SELECT DISTINCT proyectos.*, usuarios.nombre AS nombreUsuario FROM proyectos 
            JOIN usuarios ON proyectos.dniUsuario = usuarios.dni 
            LEFT JOIN proyectos_usuarios ON proyectos.id = proyectos_usuarios.proyecto_id
            WHERE ";

    if ($rolUsuario == "Administrador") {
        $sql .= "1=1";
    } elseif ($rolUsuario == "Jefe") {
        $sql .= "(proyectos.dniUsuario = :dniUsuario OR proyectos_usuarios.dniUsuario = :dniUsuario)";
        $params[":dniUsuario"] = $dniUsuario;
    } else {
        $sql .= "(proyectos_usuarios.dniUsuario = :dniUsuario)";
        $params[":dniUsuario"] = $dniUsuario;
    }

    // Agregar condición para excluir proyectos inactivos para roles distintos al administrador
    if ($rolUsuario != "Administrador") {
        $sql .= " AND proyectos.activo = 1";
    }

    // Agregar término de búsqueda a la consulta SQL
    if (!empty($busqueda)) {
        $sql .= " AND (proyectos.nombreProyecto LIKE :busqueda OR proyectos.estadoProyecto LIKE :busqueda OR proyectos.fechaFinalizacionPrevista LIKE :busqueda OR usuarios.nombre LIKE :busqueda)";
        $params[":busqueda"] = '%' . $busqueda . '%';
    }

    $sql .= " ORDER BY proyectos.nombreProyecto $orden LIMIT :inicio, :PAGS";
    
    $stmt = $con->prepare($sql);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->bindValue(":inicio", $inicio, PDO::PARAM_INT);
    $stmt->bindValue(":PAGS", $PAGS, PDO::PARAM_INT);
    $stmt->execute();
    $proyectos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $countSql = "SELECT COUNT(*) as total FROM proyectos WHERE 1=1";
    // Agregar término de búsqueda para la paginación
    if (!empty($busqueda)) {
        $countSql .= " AND (nombreProyecto LIKE :busqueda OR estadoProyecto LIKE :busqueda OR fechaFinalizacionPrevista LIKE :busqueda OR dniUsuario LIKE :busqueda)";
        $paramsCount[":busqueda"] = '%' . $busqueda . '%';
    }

    // Agregar condición para excluir proyectos inactivos para roles distintos al administrador
    if ($rolUsuario != "Administrador") {
        $countSql .= " AND activo = 1";
    }

    if (!isset($paramsCount)) {
        $paramsCount = [];
    }

    $stmt = $con->prepare($countSql);

    foreach ($paramsCount as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->execute();
    $totalResultados = $stmt->fetch(PDO::FETCH_ASSOC)["total"];
    $totalPaginas = ceil($totalResultados / $PAGS);

} catch (PDOException $e) {
    $jsAlert = "alert('Error: " . $e->getMessage() . "');";
    $redirect = "window.location.href = 'index.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <form class="d-flex pt-2" method="GET" action="">
        <input class="form-control me-2" type="search" placeholder="Buscar por nombre, estado o fecha" aria-label="Search" name="busqueda" value="<?= htmlspecialchars($busqueda) ?>">
        <button class="btn btn-outline-primary me-2" type="submit" name="buscar">Buscar</button>
        <a href="mostrarProyectos.php" class="btn btn-outline-secondary">Limpiar</a>
    </form>
    <div class="d-flex justify-content-between align-items-center mb-3 pt-3">
        <h2>Proyectos</h2>
        <?php if ($rolUsuario == "Administrador" || $rolUsuario == "Jefe") : ?>
            <a href="nuevoProyecto.php" class="btn btn-primary text-light">Crear Un Nuevo Proyecto</a>
        <?php endif; ?>
    </div>
    <div class="table-container">
        <table class="table table-responsive align-middle text-center">
            <caption class="d-none">Tabla de proyectos</caption>
            <thead class="table-primary" style="font-size: 15px;">
                <tr>
                    <?php if ($rolUsuario == "Administrador") : ?>
                        <th scope="col">Activo</th>
                    <?php endif; ?>
                    <th scope="col">Nombre</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Fecha Fin Prevista</th>
                    <th scope="col">Repositorio</th>
                    <th scope='col'>Consultar</th>
                    <th scope='col'>Ver Tareas</th>
                    <?php if ($rolUsuario == "Administrador" || $rolUsuario == "Jefe") : ?>
                        <th scope='col'>Crear Tarea</th>
                        <th scope='col'>Editar</th>
                        <th scope='col'>Cancelar</th>
                        <th scope='col'>Asignar Usuarios</th>
                    <?php endif; ?>
                </tr>
                </thead>
            <tbody style="font-size: 15px;">
                <?php foreach ($proyectos as $fila) : ?>
                    <?php
                    // Calcula la fecha actual y la fecha límite para el proyecto
                    $fechaActual = strtotime(date("Y-m-d"));
                    $fechaLimite = strtotime($fila['fechaFinalizacionPrevista']);
                    
                    // Calcula la diferencia en días entre las fechas
                    $diferenciaDias = round(($fechaLimite - $fechaActual) / (60 * 60 * 24));
                    
                    // Determina si faltan tres días o menos para la entrega del proyecto
                    $claseFecha = ($diferenciaDias <= 4) ? 'bg-danger text-light' : '';
                    ?>
                    <tr>
                        <?php if ($rolUsuario == "Administrador") : ?>
                            <td><?= $fila['activo'] ? 'Sí' : 'No' ?></td>
                        <?php endif; ?>
                        <td><?= htmlspecialchars($fila['nombreProyecto']) ?></td>
                        <?php 
                            $textoClase = strtolower($fila['estadoProyecto']) === 'finalizado' ? 'bg-success text-light' : ''; 
                        ?>
                        <td class="<?= $textoClase ?>"><?= htmlspecialchars($fila['estadoProyecto']) ?></td>
                        <td class="<?= $claseFecha ?>"><?= $fila['fechaFinalizacionPrevista'] ?></td>
                        <td><a href="<?= htmlspecialchars($fila['repositorio']) ?>"><?= htmlspecialchars($fila['repositorio']) ?></a></td>
                        <td><a href='verProyecto.php?id=<?= $fila['id'] ?>'><img src='imags/ver.png' alt='Ver' style='width: 50px; height: 50px;'></a></td>
                        <td><a href='mostrarTareas.php?id=<?= $fila['id'] ?>&proyecto_id=<?= $fila['id'] ?>'><img src='imags/vertarea.png' alt='Ver' style='width: 50px; height:50px;'></a></td>
                        <?php if ($rolUsuario == "Administrador" || $rolUsuario == "Jefe") : ?>
                        <td><a href='nuevaTarea.php?id=<?= $fila['id'] ?>&proyecto_id=<?= $fila['id'] ?>'><img src='imags/tarea.png' alt='Ver' style='width: 50px; height: 50px;'></a></td>
                        <td><a href='editarProyecto.php?id=<?= $fila['id'] ?>'><img src='imags/editar.png' alt='Editar' style='width: 50px; height: 50px;'></a></td>
                        <td><a href='borrarProyecto.php?id=<?= $fila['id'] ?>'><img src='imags/cancelar.png' alt='Cancelar' style='width: 50px; height: 50px;'></a></td>
                        <td><a href='asignarUsuarioAProyecto.php?id=<?= $fila['id'] ?>'><img src='imags/usuario.png' alt='Ver' style='width: 50px; height: 50px;'></a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <?php if ($pagina > 1) : ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?= $pagina - 1 ?>&busqueda=<?= urlencode($busqueda) ?>&orden=<?= $orden ?>" aria-label="Previous">
                        <span aria-hidden="true">«</span>
                        <span class="sr-only"></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $totalPaginas; $i++) : ?>
                <li class="page-item <?= $i == $pagina ? 'active' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $i ?>&busqueda=<?= urlencode($busqueda) ?>&orden=<?= $orden ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
            <?php if ($pagina < $totalPaginas) : ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?= $pagina + 1 ?>&busqueda=<?= urlencode($busqueda) ?>&orden=<?= $orden ?>" aria-label="Next">
                        <span aria-hidden="true">»</span>
                        <span class="sr-only"></span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
    <br>
    <a href="?orden=asc&busqueda=<?= urlencode($busqueda) ?>" class="text-decoration-none text-primary <?= $orden == 'asc' ? 'selected' : '' ?>">Nombre Asc | </a>
    <a href="?orden=desc&busqueda=<?= urlencode($busqueda) ?>" class="text-decoration-none text-primary <?= $orden == 'desc' ? 'selected' : '' ?>">Nombre Desc</a><br><br>
</main>

<?php
include "footer.php";
$con = null;
?>