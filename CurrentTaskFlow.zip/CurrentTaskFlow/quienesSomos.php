<?php
session_start();
include "funciones.php";
include "header.php";
?>

<main class="container">
    <div class="panel panel-default">
        <div class="panel-body">
            <h2>Quiénes somos</h2>
            <p class="text-primary">Bienvenido/a a mi TFG. Esto es un proyecto creado con fines académicos.</p>
            <p class="text-primary">Por favor, ten en cuenta que no garantizo que nada de lo que hagas dure para siempre.</p>
            <p class="text-primary">En cualquier momento podría ser borrado y perderías los registros de tus tareas.</p>
            <p class="text-primary">Por lo demás, puedes probar todo lo que quieras.</p>
            <p class="text-primary">Un saludo y gracias por tu comprensión.</p>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>