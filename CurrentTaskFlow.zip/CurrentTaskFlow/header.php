<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="imags/favicon.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            background-size: cover;
            background-position: center;
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: center;
            border-bottom: 2px solid #ddd;
        }

        .bg-light-blue {
            background-color: #CFE2FF;
        }
    </style>
    <title>Header</title>
</head>
<body>
    <header id="header">
        <nav class="navbar navbar-expand-lg navbar-light bg-light-blue">
                <div class="container d-flex justify-content-between align-items-center">
                    <a class="navbar-brand text-primary align-self-center" href="index.php">
                        <img src="imags/logo4.png" alt="" width="150">
                    </a>
                    <h1>CurrentTaskFlow</h1>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav" aria-controls="main_nav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse flex d-lg-flex justify-content-lg-end" id="main_nav">
                        <div class="flex">
                            <ul class="nav navbar-nav d-flex justify-content-between mx-lg-auto">
                                <li class="nav-item">
                                    <a class="nav-link text-primary" href="index.php">Inicio</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link text-primary" href="quienesSomos.php">Quiénes somos</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link text-primary" href="politicaPrivacidad.php">Política de privacidad</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link text-primary" href="contacto.php">Contacto</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-10">