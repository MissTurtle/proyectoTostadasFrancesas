<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$rolUsuario = isset($_SESSION["rol"]) ? $_SESSION["rol"] : "invitado";
$dniUsuario = $_SESSION["dni"];

$PAGS = 5;
$pagina = 1;
$inicio = 0;

if (isset($_GET["pagina"])) {
    $pagina = $_GET["pagina"];
    $inicio = ($pagina - 1) * $PAGS;
}

$orden = isset($_GET['orden']) ? $_GET['orden'] : 'asc';

$tareaId = null;
$proyectoId = null;
$nombreProyecto = '';
$nombreTarea = '';

try {
    $sql = "SELECT n.*, u.nombre AS nombreUsuario FROM notas n JOIN usuarios u ON n.dniUsuario = u.dni WHERE ";

    if (isset($_GET['proyecto_id']) && isset($_GET['tarea_id'])) {
        $proyectoId = $_GET['proyecto_id'];
        $tareaId = $_GET['tarea_id'];
        $sql .= "n.proyecto_id = :proyectoId AND n.tarea_id = :tareaId ";
    } elseif (isset($_GET['proyecto_id'])) {
        $proyectoId = $_GET['proyecto_id'];
        $sql .= "n.proyecto_id = :proyectoId AND n.tarea_id IS NULL ";
    } else {
        die('No se han especificado ni el ID de proyecto ni el ID de tarea.');
    }

    // Añadir condición para mostrar notas eliminadas solo a administradores
    if ($rolUsuario == "Administrador") {
        $sql .= "AND (n.activo = 1 OR n.activo = 0) ";
    } else {
        $sql .= "AND n.activo = 1 ";
    }

    // Consultar el nombre del proyecto
    if ($proyectoId) {
        $stmtProyecto = $con->prepare("SELECT nombreProyecto FROM proyectos WHERE id = :proyectoId");
        $stmtProyecto->bindParam(":proyectoId", $proyectoId, PDO::PARAM_INT);
        $stmtProyecto->execute();
        $proyecto = $stmtProyecto->fetch(PDO::FETCH_ASSOC);
        if ($proyecto) {
            $nombreProyecto = $proyecto['nombreProyecto'];
        }
    }

    // Consultar el nombre de la tarea
    if ($tareaId) {
        $stmtTarea = $con->prepare("SELECT nombreTarea FROM tareas WHERE id = :tareaId");
        $stmtTarea->bindParam(":tareaId", $tareaId, PDO::PARAM_INT);
        $stmtTarea->execute();
        $tarea = $stmtTarea->fetch(PDO::FETCH_ASSOC);
        if ($tarea) {
            $nombreTarea = $tarea['nombreTarea'];
        }
    }

    $stmt_count = $con->prepare("SELECT COUNT(*) as total FROM notas WHERE " . (isset($proyectoId) ? "proyecto_id = :proyectoId " : "proyecto_id IS NULL ") . "AND activo = 1");
    if (isset($proyectoId)) {
        $stmt_count->bindParam(":proyectoId", $proyectoId, PDO::PARAM_INT);
    }
    $stmt_count->execute();
    $totalResultados = $stmt_count->fetch(PDO::FETCH_ASSOC)["total"];

    $totalPaginas = ceil($totalResultados / $PAGS);

    $sql .= "ORDER BY n.nombreNota $orden LIMIT :inicio, :PAGS";
    $stmt = $con->prepare($sql);

    if (isset($proyectoId)) {
        $stmt->bindParam(":proyectoId", $proyectoId, PDO::PARAM_INT);
    }

    if (isset($tareaId)) {
        $stmt->bindParam(":tareaId", $tareaId, PDO::PARAM_INT);
    }

    $stmt->bindParam(":inicio", $inicio, PDO::PARAM_INT);
    $stmt->bindParam(":PAGS", $PAGS, PDO::PARAM_INT);
    $stmt->execute();
    $notas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $jsAlert = "alert('Error: " . $e->getMessage() . "');";
    $redirect = "window.location.href = 'index.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Notas</h2>
        <a href="<?= isset($tareaId) ? 'mostrarTareas.php?proyecto_id=' . $proyectoId : 'mostrarProyectos.php' ?>" class="btn btn-primary text-light">Volver</a>
    </div>
    <div class="mb-3 text-primary">
        <?php if ($nombreProyecto): ?>
            <h3><?= htmlspecialchars($nombreProyecto) ?></h3>
        <?php endif; ?>
        <?php if ($nombreTarea): ?>
            <h5><?= htmlspecialchars($nombreTarea) ?></h5>
        <?php endif; ?>
    </div>
    <div class="table-container">
        <table class="table table-responsive align-middle text-center">
            <caption class="d-none">Tabla de notas</caption>
            <thead class="table-primary" style="font-size: 15px;">
                <tr>
                    <?php if ($rolUsuario == 'Administrador') : ?>
                        <th scope="col">Activo</th>
                    <?php endif; ?>
                    <th scope="col">Nombre</th>
                    <th scope="col">Reporte</th>
                    <th scope="col">Evidencia</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Consultar</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Borrar</th>
                </tr>
            </thead>
            <tbody style="font-size: 15px;">
                <?php foreach ($notas as $fila) : ?>
                    <tr>
                        <?php if ($rolUsuario == 'Administrador') : ?>
                            <td><?= $fila['activo'] == 1 ? 'Sí' : 'No' ?></td>
                        <?php endif; ?>
                        <td><?= htmlspecialchars($fila['nombreNota']) ?></td>
                        <td><?= htmlspecialchars($fila['contenido']) ?></td>
                        <td>
                            <?php if ($fila['evidencia']) : ?>
                                <a href="#" onclick="verImagen('<?php echo $fila['evidencia']; ?>')">Ver</a>
                            <?php else : ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="<?= htmlspecialchars($fila['estadoNota']) == 'Finalizada' ? 'bg-success text-light' : '' ?>">
                            <?= htmlspecialchars($fila['estadoNota']) ?>
                        </td>
                        <td><a href='verNota.php?id=<?= $fila['id'] ?>&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>'><img src='imags/ver.png' alt='Ver' style='width: 50px; height: 50px;'></a></td>
                        <td><a href='editarNota.php?id=<?= $fila['id'] ?>&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>'><img src='imags/editar.png' alt='Editar' style='width: 50px; height: 50px;'></a></td>
                        <?php if ($rolUsuario != 'Empleado' || ($rolUsuario == 'Empleado' && $fila['dniUsuario'] == $dniUsuario)) : ?>
                            <td><a href='borrarNota.php?id=<?= $fila['id'] ?>&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>'><img src='imags/borrar.png' alt='Borrar' style='width: 50px; height:50px;'></a></td>
                        <?php else : ?>
                            <td>-</td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <?php if ($pagina > 1) : ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?= ($pagina - 1) ?>&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>&orden=<?= $orden ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only"></span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php for ($i = 1; $i <= $totalPaginas; $i++) : ?>
                <li class="page-item <?= $i == $pagina ? 'active' : '' ?>">
                    <a class="page-link" href="?pagina=<?= $i ?>&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>&orden=<?= $orden ?>">
                        <?= $i ?>
                    </a>
                </li>
            <?php endfor; ?>

            <?php if ($pagina < $totalPaginas) : ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?= ($pagina + 1) ?>&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>&orden=<?= $orden ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only"></span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
    <br>
    <a href="?orden=asc&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>" class="text-decoration-none text-primary <?= $orden == 'asc' ? 'selected' : '' ?>">Nombre Asc | </a>
    <a href="?orden=desc&proyecto_id=<?= $proyectoId ?>&tarea_id=<?= $tareaId ?>" class="text-decoration-none text-primary <?= $orden == 'desc' ? 'selected' : '' ?>">Nombre Desc</a><br><br>
</main>

<script>
    function verImagen(urlImagen) {
        window.open(urlImagen, 'imagenPopup', 'width=500,height=500');
    }
</script>

<?php
include "footer.php";
$con = null;
?>