<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include "funciones.php";
include "sendMail.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["actualizar"])) {
        $idTarea = $_POST["id"];
        $nombreTarea = $_POST["nombreTarea"];
        $descripcionTarea = $_POST["descripcionTarea"];
        $fechaFinalizacionPrevista = $_POST["fechaFinalizacionPrevista"];
        $estadoTarea = $_POST["estadoTarea"];
        $activo = isset($_POST["activo"]) ? 1 : 0;
        $dniUsuario = $_SESSION["dni"];

        try {
            // Obtener la fecha límite del proyecto
            $idProyecto = $_POST['proyecto_id'];
            $queryFechaLimite = "SELECT fechaFinalizacionPrevista FROM proyectos WHERE id = :idProyecto";
            $stmtFechaLimite = $con->prepare($queryFechaLimite);
            $stmtFechaLimite->bindParam(':idProyecto', $idProyecto, PDO::PARAM_INT);
            $stmtFechaLimite->execute();
            $fechaLimiteProyecto = $stmtFechaLimite->fetch(PDO::FETCH_COLUMN);

            // Comprobar si la fecha de finalización prevista es posterior a la fecha límite del proyecto
            if ($fechaFinalizacionPrevista >= $fechaLimiteProyecto) {
                echo "<script>alert('La fecha de finalización prevista de la tarea debe ser anterior a la fecha límite del proyecto.'); window.history.back();</script>";
                exit();
            }

            // Consulta SQL para obtener el estado anterior de la tarea
            $sqlEstadoAnterior = "SELECT estadoTarea FROM tareas WHERE id = :idTarea";
            $stmtEstadoAnterior = $con->prepare($sqlEstadoAnterior);
            $stmtEstadoAnterior->bindParam(":idTarea", $idTarea);
            $stmtEstadoAnterior->execute();
            $estadoAnterior = $stmtEstadoAnterior->fetchColumn();

            // Consulta SQL para actualizar la tarea (sin actualizar dniUsuario)
            $sqlTarea = "UPDATE tareas
                        SET nombreTarea = :nombreTarea, descripcionTarea = :descripcionTarea, 
                            fechaFinalizacionPrevista = :fechaFinalizacionPrevista, 
                            estadoTarea = :estadoTarea, activo = :activo
                        WHERE id = :idTarea";

            $stmtTarea = $con->prepare($sqlTarea);
            $stmtTarea->bindParam(":idTarea", $idTarea);
            $stmtTarea->bindParam(":nombreTarea", $nombreTarea);
            $stmtTarea->bindParam(":descripcionTarea", $descripcionTarea);
            $stmtTarea->bindParam(":fechaFinalizacionPrevista", $fechaFinalizacionPrevista);
            $stmtTarea->bindParam(":estadoTarea", $estadoTarea);
            $stmtTarea->bindParam(":activo", $activo);
            $stmtTarea->execute();

            // Verificar si el estado ha cambiado y enviar el correo correspondiente
            if ($estadoTarea != $estadoAnterior) {
                // Obtener el DNI del usuario que creó el proyecto
                $sqlDNIUsuario = "SELECT dniUsuario FROM proyectos WHERE id = :idProyecto";
                $stmtDNIUsuario = $con->prepare($sqlDNIUsuario);
                $stmtDNIUsuario->bindParam(":idProyecto", $idProyecto);
                $stmtDNIUsuario->execute();
                $dniUsuarioProyecto = $stmtDNIUsuario->fetchColumn();

                // Obtener la información completa del usuario que creó el proyecto
                $sqlUsuario = "SELECT * FROM usuarios WHERE dni = :dniUsuarioProyecto";
                $stmtUsuario = $con->prepare($sqlUsuario);
                $stmtUsuario->bindParam(":dniUsuarioProyecto", $dniUsuarioProyecto);
                $stmtUsuario->execute();
                $usuarioProyecto = $stmtUsuario->fetch(PDO::FETCH_ASSOC);

                // Obtener el nombre del proyecto asociado a la tarea
                $sqlNombreProyecto = "SELECT nombreProyecto FROM proyectos WHERE id = :idProyecto";
                $stmtNombreProyecto = $con->prepare($sqlNombreProyecto);
                $stmtNombreProyecto->bindParam(":idProyecto", $idProyecto);
                $stmtNombreProyecto->execute();
                $nombreProyecto = $stmtNombreProyecto->fetchColumn();

                $mensajePersonalizado = "La tarea \"" . $nombreTarea . "\" del proyecto \"" . $nombreProyecto . "\" ha cambiado a: " . $estadoTarea;

                // Enviar un correo electrónico al creador del proyecto
                $to = $usuarioProyecto['email'];
                $subject = "Cambio de estado de tarea en proyecto";
                $body = $mensajePersonalizado . ".<br><br>Entra en CurrentTaskFlow para más detalles.";
                sendMail($to, $subject, $body);

                $jsAlert = "alert('Cambios guardados correctamente. Se ha enviado un correo electrónico al creador del proyecto.');";
            } else {
                $jsAlert = "alert('Cambios guardados correctamente.');";
            }

            $redirect = "window.location.href = 'mostrarTareas.php?id=" . $_POST['proyecto_id'] . "&proyecto_id=" . $_POST['proyecto_id'] . "';";
        } catch (PDOException $e) {
            $jsAlert = "alert('Error: " . $e->getMessage() . "');";
            $redirect = "window.location.href = 'mostrarTareas.php?id=" . $_POST['proyecto_id'] . "&proyecto_id=" . $_POST['proyecto_id'] . "';";
        }
    }
}

if (isset($_GET["id"])) {
    $idTarea = $_GET["id"];

    try {
        // Obtener información de la tarea
        $sqlTarea = "SELECT * FROM tareas WHERE id = :idTarea";
        $stmtTarea = $con->prepare($sqlTarea);
        $stmtTarea->bindParam(":idTarea", $idTarea);
        $stmtTarea->execute();
        $tarea = $stmtTarea->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarProyectos.php';";
    }
} else {
    $redirect = "window.location.href = 'mostrarProyectos.php';";
}

// Definir hidden dependiendo del rol del usuario
if ($_SESSION["rol"] == "Empleado") {
$hidden = "hidden";
} else {
$hidden = "";
}

if (!empty($jsAlert) || !empty($redirect)) {
echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Introduce los nuevos datos de la tarea</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formedi" method="POST" enctype="multipart/form-data" onsubmit="return validarFechas()">
        <div class="mb-3">
            <input type="hidden" class="form-control" name="id" value="<?php echo $tarea['id']; ?>">
            <input type="hidden" class="form-control" name="proyecto_id" value="<?php echo $_GET['proyecto_id']; ?>">
        </div>
        <div class="mb-3" <?php echo $hidden; ?>>
            <label for="nombreTarea" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombreTarea" value="<?php echo $tarea['nombreTarea']; ?>" required>
        </div>
        <div class="mb-3" <?php echo $hidden; ?>>
            <label for="descripcionTarea" class="form-label">Descripción de la Tarea:</label>
            <textarea class="form-control w-25" name="descripcionTarea" rows="4" required><?php echo $tarea['descripcionTarea']; ?></textarea>
        </div>
        <div class="mb-3" <?php echo $hidden; ?>>
            <label for="fechaFinalizacionPrevista" class="form-label">Fecha de Finalización Prevista:</label>
            <input type="date" class="form-control w-25" id="fechaFinalizacionPrevista" name="fechaFinalizacionPrevista" value="<?php echo $tarea['fechaFinalizacionPrevista']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="estadoTarea" class="form-label">Estado de la Tarea:</label>
            <select name="estadoTarea" required>
                <option value="Pendiente" <?php echo ($tarea['estadoTarea'] == 'Pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                <option value="Iniciada" <?php echo ($tarea['estadoTarea'] == 'Iniciada') ? 'selected' : ''; ?>>Iniciada</option>
                <option value="En Revisión" <?php echo ($tarea['estadoTarea'] == 'En Revisión') ? 'selected' : ''; ?>>En Revisión</option>
                <option value="Finalizada" <?php echo ($tarea['estadoTarea'] == 'Finalizada') ? 'selected' : ''; ?>>Finalizada</option>
            </select>
        </div>
        <div class="mb-3" <?php echo $hidden; ?>>
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" <?php echo $tarea["activo"] ? "checked" : ""; ?>>
        </div>
        <input type="submit" class="btn btn-primary text-light" name="actualizar" value="Actualizar Datos"><br><br>
    </form>
</main>

<script>
    function validarFechas() {
        // Obtenemos la fecha actual
        var fechaActual = new Date();
        var dd = String(fechaActual.getDate()).padStart(2, '0');
        var mm = String(fechaActual.getMonth() + 1).padStart(2, '0');
        var yyyy = fechaActual.getFullYear();
        var fechaActualStr = yyyy + '-' + mm + '-' + dd;

        var fechaFinalizacion = document.getElementById("fechaFinalizacionPrevista").value;

        // Comprobar si la fecha de finalización prevista es anterior a la actual
        if (fechaFinalizacion < fechaActualStr) {
            alert("La fecha de finalización prevista no puede ser anterior a la fecha actual.");
            return false;
        }
        return true;
    }
</script>

<?php
include "footer.php";
$con = null;
?>