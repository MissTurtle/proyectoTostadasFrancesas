<?php
session_start();
include "funciones.php";

if (isset($_SESSION["dni"])) {
    header("Location: index.php");
    exit();
}

$jsAlert = "";
$redirect = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dni = $_POST["dni"];
    $contrasenya = $_POST["contrasenya"];

    $funciones = new Funciones();

    // Compruebo que el DNI cumple los requisitos
    if ($funciones->validarDNI($dni)) {
        try {
            // Consulta prepare
            $stmt = $con->prepare("SELECT dni, contrasenya, rol, nombre, direccion, localidad, provincia, telefono, email, activo 
                                    FROM usuarios 
                                    WHERE dni = :dni");
            $stmt->bindParam(":dni", $dni);
            $stmt->execute();

            $fila = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($fila) {
                // Almacena el valor de activo en una variable de sesión
                $_SESSION["usuario_activo"] = $fila["activo"];

                // Verifica si el usuario está activo
                if ($_SESSION["usuario_activo"] == 1) {
                    // Verifico la contraseña
                    if (password_verify($contrasenya, $fila["contrasenya"])) {
                        // Almaceno la información del usuario en la sesión
                        $_SESSION["dni"] = $fila["dni"];
                        $_SESSION["rol"] = $fila["rol"];
                        $_SESSION["usuario"] = [
                            'nombre' => $fila["nombre"],
                            'direccion' => $fila["direccion"],
                            'localidad' => $fila["localidad"],
                            'provincia' => $fila["provincia"],
                            'telefono' => $fila["telefono"],
                            'email' => $fila["email"],
                            'activo' => $fila["activo"]
                        ];

                        if (isset($_SESSION['url_origen'])) {
                            $url_origen = $_SESSION['url_origen'];
                            unset($_SESSION['url_origen']);
                            $redirect = "window.location.href = '$url_origen';";
                        } else {
                            $redirect = "window.location.href = 'index.php';";
                        }
                    } else {
                        $jsAlert = "alert('Error: Contraseña incorrecta.');";
                        $redirect = "window.location.href = 'index.php';";
                    }
                } else {
                    // El usuario no está activo, destruye la sesión y muestra un mensaje de error
                    session_destroy();
                    $jsAlert = "alert('Error: El usuario no está activo. Por favor, contacte al administrador.');";
                    $redirect = "window.location.href = 'index.php';";
                }
            } else {
                $jsAlert = "alert('Error: Vuelva a introducir los datos.');";
                $redirect = "window.location.href = 'index.php';";
            }
        } catch (PDOException $e) {
            $jsAlert = "alert('Error: " . $e->getMessage() . "');";
            $redirect = "window.location.href = 'index.php';";
        }
    } else {
        $jsAlert = "alert('Error: DNI no válido.');";
        $redirect = "window.location.href = 'index.php';";
    }
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <?php if (empty($jsAlert) && empty($redirect)): ?>
        <h2 class="text-center text-primary">Debes iniciar sesión</h2>
        <form name="loginForm" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="dni" class="form-label">DNI</label>
                <input type="text" class="form-control" name="dni" maxlength="9" required>
            </div>
            <div class="mb-3">
                <label for="contrasenya" class="form-label">Contraseña</label>
                <input type="password" class="form-control" name="contrasenya" maxlength="30" required>
            </div>
            <div class="mb-3">
                <input type="submit" class="btn btn-primary text-black" value="Iniciar Sesión"><br><br>
            </div>
        </form>
    <?php endif; ?>
</main>

<?php
include "footer.php";
$con = null;
?>