<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombreProyecto = $_POST["nombreProyecto"];
    $descripcionProyecto = $_POST["descripcionProyecto"];
    $repositorio = $_POST["repositorio"];
    $fechaFinalizacionPrevista = $_POST["fechaFinalizacionPrevista"];
    $estadoProyecto = $_POST["estadoProyecto"];
    $activo = isset($_POST["activo"]) ? 1 : 0;
    $dniUsuario = $_SESSION["dni"];

    try {
        $query = "INSERT INTO proyectos (nombreProyecto, descripcionProyecto, repositorio, fechaCreacion, fechaFinalizacionPrevista, estadoProyecto, activo, dniUsuario) VALUES (:nombreProyecto, :descripcionProyecto, :repositorio, current_timestamp(), :fechaFinalizacionPrevista, :estadoProyecto, :activo, :dniUsuario)";
        $stmt = $con->prepare($query);

        $stmt->bindParam(':nombreProyecto', $nombreProyecto, PDO::PARAM_STR);
        $stmt->bindParam(':descripcionProyecto', $descripcionProyecto, PDO::PARAM_STR);
        $stmt->bindParam(':repositorio', $repositorio, PDO::PARAM_STR);
        $stmt->bindParam(':fechaFinalizacionPrevista', $fechaFinalizacionPrevista, PDO::PARAM_STR);
        $stmt->bindParam(':estadoProyecto', $estadoProyecto, PDO::PARAM_STR);
        $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
        $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);

        $stmt->execute();

        $jsAlert = "alert('Proyecto agregado con éxito.');";
        $redirect = "window.location.href = 'mostrarProyectos.php';";
    } catch (PDOException $e) {
        $jsAlert = "alert('Error al agregar el proyecto: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'nuevoProyecto.php';";
    }
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Crea un nuevo proyecto</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formnpro" method="POST" enctype="multipart/form-data" onsubmit="return validarFechas()">
        <div class="mb-3">
            <label for="nombreProyecto" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombreProyecto" required>
        </div>
        <div class="mb-3">
            <label for="descripcionProyecto" class="form-label">Descripción del Proyecto:</label>
            <textarea class="form-control w-25" name="descripcionProyecto" required></textarea>
        </div>
        <div class="mb-3">
            <label for="repositorio" class="form-label">Repositorio del proyecto:</label>
            <input type="text" class="form-control w-25" name="repositorio">
        </div>
        <div class="mb-3">
            <label for="fechaFinalizacionPrevista" class="form-label">Fecha de Finalización Prevista:</label>
            <input type="date" class="form-control w-25" name="fechaFinalizacionPrevista" id="fechaFinalizacionPrevista" required>
        </div>
        <div class="mb-3">
            <label for="estadoProyecto" class="form-label">Estado del Proyecto:</label>
            <select name="estadoProyecto" required>
                <option value="Iniciado">Iniciado</option>
                <option value="Finalizado">Finalizado</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" <?php echo isset($_POST["activo"]) && $_POST["activo"] == "1" ? "checked" : "checked"; ?>>
        </div>
        <div class="mb-3">
            <input type="reset" class="btn btn-primary text-light" name="Borrar" value="Borrar datos">
            <input type="submit" class="btn btn-primary text-light" name="Enviar" value="Enviar datos"><br><br>
        </div>
    </form>
    </main>

<script>
    function validarFechas() {
        // Obtenemos la fecha actual
        var fechaActual = new Date();
        var dd = String(fechaActual.getDate()).padStart(2, '0');
        var mm = String(fechaActual.getMonth() + 1).padStart(2, '0');
        var yyyy = fechaActual.getFullYear();
        var fechaActualStr = yyyy + '-' + mm + '-' + dd;

        var fechaFinalizacion = document.getElementById("fechaFinalizacionPrevista").value;

        // Comprobar si la fecha de finalización prevista es anterior a la actual
        if (fechaFinalizacion < fechaActualStr) {
            alert("La fecha de finalización prevista no puede ser anterior a la fecha actual.");
            return false;
        }
        return true;
    }
</script>

<?php
include "footer.php";
$con = null;
?>