<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include "funciones.php";
include "sendMail.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idNota = $_POST["id"];
    $nombreNota = $_POST["nombreNota"];
    $contenido = $_POST["contenido"];
    $estadoNota = $_POST["estadoNota"];
    $activo = isset($_POST["activo"]) ? 1 : 0;
    $evidencia = $_FILES['evidencia']['name'];
    
    // Obtener la URL actual de la evidencia
    $sqlEvidenciaActual = "SELECT evidencia FROM notas WHERE id = :idNota";
    $stmtEvidenciaActual = $con->prepare($sqlEvidenciaActual);
    $stmtEvidenciaActual->bindParam(":idNota", $idNota, PDO::PARAM_INT);
    $stmtEvidenciaActual->execute();
    $evidenciaActual = $stmtEvidenciaActual->fetchColumn();

    if (empty($evidencia)) {
        // Si no se selecciona una nueva evidencia, conservar la existente
        $evidencia = $evidenciaActual;
    } else {
        $targetDir = "Descargas/";
        $fileName = uniqid() . "_" . basename($evidencia); // Generar un nombre único
        $targetFile = $targetDir . $fileName;
        if (move_uploaded_file($_FILES["evidencia"]["tmp_name"], $targetFile)) {
            $evidencia = $targetFile;
        } else {
            $jsAlert = "alert('Error al subir el archivo.');";
            echo "<script>$jsAlert</script>";
            exit();
        }
    }

    try {
        // Consulta SQL para obtener el estado anterior de la nota
        $sqlEstadoAnterior = "SELECT estadoNota FROM notas WHERE id = :idNota";
        $stmtEstadoAnterior = $con->prepare($sqlEstadoAnterior);
        $stmtEstadoAnterior->bindParam(":idNota", $idNota, PDO::PARAM_INT);
        $stmtEstadoAnterior->execute();
        $estadoAnterior = $stmtEstadoAnterior->fetchColumn();

        // Consulta SQL para actualizar la nota sin cambiar el dniUsuario
        $sqlNota = "UPDATE notas
                    SET nombreNota = :nombreNota, contenido = :contenido, estadoNota = :estadoNota, activo = :activo, evidencia = :evidencia
                    WHERE id = :idNota";

        $stmtNota = $con->prepare($sqlNota);
        $stmtNota->bindParam(":idNota", $idNota, PDO::PARAM_INT);
        $stmtNota->bindParam(":nombreNota", $nombreNota, PDO::PARAM_STR);
        $stmtNota->bindParam(":contenido", $contenido, PDO::PARAM_STR);
        $stmtNota->bindParam(":estadoNota", $estadoNota, PDO::PARAM_STR);
        $stmtNota->bindParam(":activo", $activo, PDO::PARAM_BOOL);
        $stmtNota->bindParam(":evidencia", $evidencia, PDO::PARAM_STR);
        $stmtNota->execute();

        // Verificar si el estado ha cambiado y enviar el correo correspondiente
        if ($estadoNota != $estadoAnterior) {
            // Obtener el ID del proyecto asociado a la nota
            $idProyecto = $_POST['proyecto_id'];
            $idTarea = $_POST['tarea_id'];
            
            // Obtener el DNI del usuario que creó el proyecto
            $sqlDNIUsuario = "SELECT dniUsuario FROM proyectos WHERE id = :idProyecto";
            $stmtDNIUsuario = $con->prepare($sqlDNIUsuario);
            $stmtDNIUsuario->bindParam(":idProyecto", $idProyecto, PDO::PARAM_INT);
            $stmtDNIUsuario->execute();
            $dniUsuarioProyecto = $stmtDNIUsuario->fetchColumn();

            // Obtener la información completa del usuario que creó el proyecto
            $sqlUsuario = "SELECT * FROM usuarios WHERE dni = :dniUsuarioProyecto";
            $stmtUsuario = $con->prepare($sqlUsuario);
            $stmtUsuario->bindParam(":dniUsuarioProyecto", $dniUsuarioProyecto, PDO::PARAM_STR);
            $stmtUsuario->execute();
            $usuarioProyecto = $stmtUsuario->fetch(PDO::FETCH_ASSOC);

            // Obtener el nombre del proyecto asociado a la nota
            $sqlNombreProyecto = "SELECT nombreProyecto FROM proyectos WHERE id = :idProyecto";
            $stmtNombreProyecto = $con->prepare($sqlNombreProyecto);
            $stmtNombreProyecto->bindParam(":idProyecto", $idProyecto, PDO::PARAM_INT);
            $stmtNombreProyecto->execute();
            $nombreProyecto = $stmtNombreProyecto->fetchColumn();

            // Obtener el nombre de la tarea
            $sqlNombreTarea = "SELECT nombreTarea FROM tareas WHERE id = :idTarea";
            $stmtNombreTarea = $con->prepare($sqlNombreTarea);
            $stmtNombreTarea->bindParam(":idTarea", $idTarea);
            $stmtNombreTarea->execute();
            $nombreTarea = $stmtNombreTarea->fetchColumn();

            $mensajePersonalizado = "La nota reportada " . $nombreNota . " sobre el proyecto " . $nombreProyecto . " ha cambiado a: " . $estadoNota;

            // Enviar un correo electrónico al creador del proyecto
            $to = $usuarioProyecto['email'];
            $subject = "Cambio de estado de nota en proyecto";
            $body = $mensajePersonalizado . ". Entra en CurrentTaskFlow para más detalles.";
            sendMail($to, $subject, $body);

            $jsAlert = "alert('Cambios guardados correctamente. Se ha enviado un correo electrónico al creador del proyecto.');";
        } else {
            $jsAlert = "alert('Cambios guardados correctamente.');";
        }

        $redirect = "window.location.href = 'mostrarNotas.php";
        if (isset($_GET["proyecto_id"])) {
            $redirect .= "?proyecto_id=" . $_GET["proyecto_id"];
            if (isset($_GET["tarea_id"])) {
                $redirect .= "&tarea_id=" . $_GET["tarea_id"];
            } else {
                $redirect .= "&tarea_id=null";
            }
        }
        $redirect .= "';";
        echo "<script>$jsAlert $redirect</script>";
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        echo "<script>$jsAlert</script>";
    }
}

if (isset($_GET["id"])) {
    $idNota = $_GET["id"];

    try {
        // Obtener información de la nota
        $sqlNota = "SELECT * FROM notas WHERE id = :idNota";
        $stmtNota = $con->prepare($sqlNota);
        $stmtNota->bindParam(":idNota", $idNota, PDO::PARAM_INT);
        $stmtNota->execute();
        $nota = $stmtNota->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        echo "<script>$jsAlert</script>";
    }
} else {
    $jsAlert = "alert('No se ha proporcionado un ID de nota válido.');";
    echo "<script>$jsAlert</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Introduce los nuevos datos de la nota</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formedi" method="POST" enctype="multipart/form-data">
        <div class="mb-3" <?php echo ($_SESSION["rol"] == "Empleado") ? 'hidden' : ''; ?>>
            <input type="hidden" class="form-control" name="id" value="<?php echo htmlspecialchars($nota['id']); ?>">
            <input type="hidden" class="form-control" name="proyecto_id" value="<?php echo $_GET['proyecto_id']; ?>">
        </div>
        <div class="mb-3" <?php echo ($_SESSION["rol"] == "Empleado") ? 'hidden' : ''; ?>>
            <label for="nombreNota" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombreNota" value="<?php echo htmlspecialchars($nota['nombreNota']); ?>" required>
        </div>
        <div class="mb-3" <?php echo ($_SESSION["rol"] == "Empleado") ? 'hidden' : ''; ?>>
            <label for="contenido" class="form-label">Reporte:</label>
            <textarea class="form-control w-25" name="contenido" rows="4" required><?php echo htmlspecialchars($nota['contenido']); ?></textarea>
        </div>
        <div class="mb-3" <?php echo ($_SESSION["rol"] == "Empleado") ? 'hidden' : ''; ?>>
            <label for="evidencia" class="form-label">Evidencia: (No seleccionar nada para no cambiar)</label>
            <input type="file" class="form-control w-25" name="evidencia" accept="image/*">
        </div>
        <div class="mb-3">
            <label for="estadoNota" class="form-label">Estado de la Nota:</label>
            <select name="estadoNota" required>
                <option value="Pendiente" <?php echo ($nota['estadoNota'] == 'Pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                <option value="Iniciada" <?php echo ($nota['estadoNota'] == 'Iniciada') ? 'selected' : ''; ?>>Iniciada</option>
                <option value="En Revisión" <?php echo ($nota['estadoNota'] == 'En Revisión') ? 'selected' : ''; ?>>En Revisión</option>
                <option value="Finalizada" <?php echo ($nota['estadoNota'] == 'Finalizada') ? 'selected' : ''; ?>>Finalizada</option>
            </select>
        </div>
        <div class="mb-3" <?php echo ($_SESSION["rol"] == "Empleado") ? 'hidden' : ''; ?>>
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" <?php echo $nota["activo"] ? "checked" : ""; ?>>
        </div>
        <input type="submit" class="btn btn-primary text-light" name="actualizar" value="Actualizar Datos"><br><br>
    </form>
</main>

<?php
include "footer.php";
$con = null;
?>