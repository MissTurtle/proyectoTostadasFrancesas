<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    try {
        // Consulta SQL para obtener los datos del proyecto
        $sql = "SELECT * FROM proyectos WHERE id = :id";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        // Guardo la fila del proyecto
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fila) {
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirmar"])) {
                // Actualizo el campo "activo" a 0 en lugar de borrar el proyecto
                $sqlActualizar = "UPDATE proyectos SET activo = 0 WHERE id = :id";
                $stmtActualizar = $con->prepare($sqlActualizar);
                $stmtActualizar->bindParam(":id", $id, PDO::PARAM_INT);

                if ($stmtActualizar->execute()) {
                    $jsAlert = "alert('El proyecto " . $fila["nombreProyecto"] . " ha sido cancelado.');";
                    $redirect = "window.location.href = 'mostrarProyectos.php';";
                } else {
                    $jsAlert = "alert('Error al cancelar el proyecto.');";
                    $redirect = "window.location.href = 'mostrarProyectos.php';";
                }
            }
        } else {
            $redirect = "window.location.href = 'mostrarProyectos.php';";
        }
    } catch (PDOException $e) {
        $jsAlert = "alert('Error: " . $e->getMessage() . "');";
        $redirect = "window.location.href = 'mostrarProyectos.php';";
    }
} else {
    $redirect = "window.location.href = 'mostrarProyectos.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Cancelar proyecto</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <?php if (isset($fila)): ?>
    <p>¿Seguro que quieres cancelar el proyecto <?php echo $fila["nombreProyecto"]; ?>?</p>
    <form name="formconf" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
        </div>
        <div class="mb-3">
            <input type="submit" class="btn btn-primary text-light" name="confirmar" value="Confirmar"><br>
        </div>
    </form>
    <?php else: ?>
    <p>Proyecto no encontrado.</p>
    <?php endif; ?>
</main>

<?php
include "footer.php";
$con = null;
?>