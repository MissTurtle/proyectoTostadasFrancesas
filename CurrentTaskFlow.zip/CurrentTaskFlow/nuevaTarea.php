<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['proyecto_id'])) {
    $proyectoId = $_GET['proyecto_id'];
} else {
    die('No se ha especificado un ID de proyecto.');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreTarea = $_POST["nombreTarea"];
    $descripcionTarea = $_POST["descripcionTarea"];
    $fechaFinalizacionPrevista = $_POST["fechaFinalizacionPrevista"];
    $estadoTarea = $_POST["estadoTarea"];
    $activo = isset($_POST["activo"]) ? 1 : 0;
    $dniUsuario = $_SESSION["dni"];
    $proyectoId = $_POST["proyecto_id"];

    $fechaCreacion = date("Y-m-d H:i:s");

    // Obtener la fecha límite del proyecto
    $queryFechaLimite = "SELECT fechaFinalizacionPrevista FROM proyectos WHERE id = :proyectoId";
    $stmtFechaLimite = $con->prepare($queryFechaLimite);
    $stmtFechaLimite->bindParam(':proyectoId', $proyectoId, PDO::PARAM_INT);
    $stmtFechaLimite->execute();
    $fechaLimiteProyecto = $stmtFechaLimite->fetch(PDO::FETCH_COLUMN);

    if ($fechaFinalizacionPrevista >= $fechaLimiteProyecto) {
        echo "<script>alert('La fecha de finalización prevista de la tarea debe ser anterior a la fecha límite del proyecto.'); window.history.back();</script>";
    } else {
        try {
            $query = "INSERT INTO tareas (nombreTarea, descripcionTarea, fechaCreacion, fechaFinalizacionPrevista, estadoTarea, activo, dniUsuario, proyecto_id) 
                      VALUES (:nombreTarea, :descripcionTarea, :fechaCreacion, :fechaFinalizacionPrevista, :estadoTarea, :activo, :dniUsuario, :proyecto_id)";
            $stmt = $con->prepare($query);

            $stmt->bindParam(':nombreTarea', $nombreTarea, PDO::PARAM_STR);
            $stmt->bindParam(':descripcionTarea', $descripcionTarea, PDO::PARAM_STR);
            $stmt->bindParam(':fechaCreacion', $fechaCreacion, PDO::PARAM_STR);
            $stmt->bindParam(':fechaFinalizacionPrevista', $fechaFinalizacionPrevista, PDO::PARAM_STR);
            $stmt->bindParam(':estadoTarea', $estadoTarea, PDO::PARAM_STR);
            $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
            $stmt->bindParam(':dniUsuario', $dniUsuario, PDO::PARAM_STR);
            $stmt->bindParam(':proyecto_id', $proyectoId, PDO::PARAM_INT);

            $stmt->execute();

            echo "<script>alert('Tarea agregada con éxito.'); window.location.href = 'mostrarProyectos.php?id=$proyectoId';</script>";
        } catch (PDOException $e) {
            echo "<script>alert('Error al agregar la tarea: " . $e->getMessage() . "'); window.history.back();</script>";
        }
    }
}

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Crea una nueva tarea</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <form name="formnpro" method="POST" enctype="multipart/form-data" onsubmit="return validarFechas()">
        <input type="hidden" name="proyecto_id" value="<?= htmlspecialchars($proyectoId) ?>">
        <div class="mb-3">
            <label for="nombreTarea" class="form-label">Nombre:</label>
            <input type="text" class="form-control w-25" name="nombreTarea" required>
        </div>
        <div class="mb-3">
            <label for="descripcionTarea" class="form-label">Descripción de la Tarea:</label>
            <textarea class="form-control w-25" name="descripcionTarea" required></textarea>
        </div>
        <div class="mb-3">
            <label for="fechaFinalizacionPrevista" class="form-label">Fecha de Finalización Prevista:</label>
            <input type="date" class="form-control w-25" name="fechaFinalizacionPrevista" id="fechaFinalizacionPrevista" required>
        </div>
        <div class="mb-3">
            <label for="estadoTarea" class="form-label">Estado de la Tarea:</label>
            <select name="estadoTarea" required>
                <option value="Pendiente">Pendiente</option>
                <option value="Iniciada">Iniciada</option>
                <option value="En revisión">En revisión</option>
                <option value="Finalizada">Finalizada</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="activo" class="form-check-label">Activo:</label>
            <input type="checkbox" class="form-check-input" name="activo" checked>
        </div>
        <div class="mb-3">
            <input type="reset" class="btn btn-primary text-light" name="Borrar" value="Borrar datos">
            <input type="submit" class="btn btn-primary text-light" name="Enviar" value="Enviar datos"><br><br>
        </div>
    </form>
</main>

<script>
    function validarFechas() {
        // Obtenemos la fecha actual
        var fechaActual = new Date();
        var dd = String(fechaActual.getDate()).padStart(2, '0');
        var mm = String(fechaActual.getMonth() + 1).padStart(2, '0');
        var yyyy = fechaActual.getFullYear();
        var fechaActualStr = yyyy + '-' + mm + '-' + dd;

        var fechaFinalizacion = document.getElementById("fechaFinalizacionPrevista").value;

        // Comprobar si la fecha de finalización prevista es anterior a la actual
        if (fechaFinalizacion < fechaActualStr) {
            alert("La fecha de finalización prevista no puede ser anterior a la fecha actual.");
            return false;
        }
        return true;
    }
</script>

<?php
include "footer.php";
$con = null;
?>