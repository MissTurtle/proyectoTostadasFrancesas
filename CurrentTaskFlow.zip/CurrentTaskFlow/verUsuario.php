<?php
session_start();
include "funciones.php";
include "usuario.php";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

$dni = $_GET['dni'];

$funciones = new Funciones();
$usuarios = $funciones->obtenerUsuarios();

$usuarioEncontrado = array_values(array_filter($usuarios, function ($usuario) use ($dni) {
    return $usuario->getDNI() == $dni;
}));

include "header.php";
?>

<main class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Informacion del usuario</h2>
        <button class="btn btn-primary text-light" onclick="window.history.back()">Volver</button>
    </div>
    <div class="row mt-3 mb-3">
        <div class="col-md-4">
        <?php
        if (!empty($usuarioEncontrado)) {
            $activo = $usuarioEncontrado[0]->getActivo() ? "Sí" : "No";
            ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">DNI: <?php echo $usuarioEncontrado[0]->getDNI(); ?></h5>
                    <p class="card-text">Nombre: <?php echo $usuarioEncontrado[0]->getNombre(); ?></p>
                    <p class="card-text">Dirección: <?php echo $usuarioEncontrado[0]->getDireccion(); ?></p>
                    <p class="card-text">Localidad: <?php echo $usuarioEncontrado[0]->getLocalidad(); ?></p>
                    <p class="card-text">Provincia: <?php echo $usuarioEncontrado[0]->getProvincia(); ?></p>
                    <p class="card-text">Teléfono: <?php echo $usuarioEncontrado[0]->getTelefono(); ?></p>
                    <p class="card-text">Email: <?php echo $usuarioEncontrado[0]->getEmail(); ?></p>
                    <p class="card-text">Rol: <?php echo $usuarioEncontrado[0]->getRol(); ?></p>
                    <p class="card-text">Activo: <?php echo $activo; ?></p>
                </div>
            </div>
            <?php
        }
        ?>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>