<?php
session_start();
include "funciones.php";

$jsAlert = "";
$redirect = "";

if (!isset($_SESSION["dni"])) {
    header("Location: login.php");
    exit();
}

// Obtener el rol del usuario que ha iniciado sesión
$rolUsuario = isset($_SESSION["rol"]) ? $_SESSION["rol"] : "";

$PAGS = 5;
$pagina = 1;
$inicio = 0;

if (isset($_GET["pagina"])) {
    $pagina = $_GET["pagina"];
    $inicio = ($pagina - 1) * $PAGS;
}

// Obtener el valor de orden
$orden = isset($_GET["orden"]) ? $_GET["orden"] : "asc";

// Obtener el término de búsqueda
$busqueda = isset($_GET["busqueda"]) ? $_GET["busqueda"] : "";

$sql = "";
$params = [];

try {
    // Consulta SQL
    if ($rolUsuario == "Administrador") {
        // Mostrar todos los usuarios si es administrador
        $sql = "SELECT * FROM usuarios WHERE 1=1";
    } elseif (in_array($rolUsuario, ["Empleado", "Jefe"])) {
        // Mostrar solo los datos del usuario con ese DNI si es usuario, empleado o jefe
        $dniUsuario = $_SESSION["dni"];
        $sql = "SELECT * FROM usuarios WHERE dni = :dni";
        $params[":dni"] = $dniUsuario;
    }

    // Si hay un término de búsqueda, agregar la cláusula WHERE
    if (!empty($busqueda)) {
        $sql .= " AND (nombre LIKE :busqueda OR email LIKE :busqueda OR rol LIKE :busqueda)";
        $params[":busqueda"] = '%' . $busqueda . '%';
    }

    $sql .= " ORDER BY nombre $orden";
    $sql .= " LIMIT :inicio, :PAGS";
    
    $stmt = $con->prepare($sql);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->bindValue(":inicio", $inicio, PDO::PARAM_INT);
    $stmt->bindValue(":PAGS", $PAGS, PDO::PARAM_INT);

    $stmt->execute();
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $jsAlert = "alert('Error: " . $e->getMessage() . "');";
    $redirect = "window.location.href = 'index.php';";
}

if (!empty($jsAlert) || !empty($redirect)) {
    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <?php if ($rolUsuario == "Administrador"): ?>
        <form class="d-flex pt-2" method="GET" action="">
            <input class="form-control me-2" type="search" placeholder="Buscar por nombre, e-mail o rol" aria-label="Search" name="busqueda" value="<?= htmlspecialchars($busqueda) ?>">
            <button class="btn btn-outline-primary me-2" type="submit" name="buscar">Buscar</button>
            <a href="mostrarUsuarios.php" class="btn btn-outline-secondary">Limpiar</a>
        </form>
    <?php endif; ?>
    <div class="d-flex justify-content-between align-items-center mb-3 pt-3">
        <h2>Usuarios</h2>
        <?php if ($rolUsuario == "Administrador"): ?>
            <a href="nuevoUsuario.php" class="btn btn-primary text-light">Crear Un Nuevo Usuario</a>
        <?php endif; ?>
    </div>
    <div class="table-container">
        <table class="table table-responsive align-middle text-center">
        <caption class="d-none">Tabla de usuarios</caption>
        <thead class="table-primary" style="font-size: 15px;">
            <tr>
                <?php if ($rolUsuario == "Administrador"): ?>
                    <th scope="col">Activo</th>
                <?php endif; ?>
                <th scope="col">Nombre</th>
                <th scope="col">E-mail</th>
                <th scope="col">Rol</th>
                <th scope="col">Consultar</th>
                <th scope="col">Editar</th>
                <th scope="col">Borrar</th>
            </tr>
        </thead>
        <tbody style="font-size: 15px;">
            <?php
            $stmt = $con->prepare("SELECT COUNT(*) as total FROM usuarios");
            $stmt->execute();

            $totalResultados = $stmt->fetch(PDO::FETCH_ASSOC)["total"];
            $totalPaginas = ceil($totalResultados / $PAGS);

            foreach ($usuarios as $fila) {
                echo "<tr>";
                if ($rolUsuario == "Administrador") {
                    echo "<td>" . ($fila['activo'] == 1 ? 'Sí' : 'No') . "</td>";
                }
                echo "<td>{$fila['nombre']}</td>";
                echo "<td>{$fila['email']}</td>";
                echo "<td>{$fila['rol']}</td>";
                echo "<td><a href='verUsuario.php?dni={$fila['dni']}'><img src='imags/ver.png' alt='Ver' style='width: 50px; height: 50px;'></a></td>";
                echo "<td><a href='editarUsuario.php?dni={$fila['dni']}'><img src='imags/editar.png' alt='Editar' style='width: 50px; height: 50px;'></a></td>";
                echo "<td><a href='borrarUsuario.php?dni={$fila['dni']}'><img src='imags/borrar.png' alt='Borrar' style='width: 50px; height: 50px;'></a></td>";
                echo "</tr>";
            }
            echo "</table>";
            ?>
        </tbody>
    </div>

    <?php if ($rolUsuario == "Administrador"): ?>
        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-center">
            <?php if ($pagina > 1): ?>
                <li class="page-item">
                  <a class="page-link" href="?pagina=<?= $pagina - 1 ?>&busqueda=<?= urlencode($busqueda) ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                  </a>
                </li>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $totalPaginas; $i++) : ?>
                <?php if ($i == $pagina): ?>
                    <li class="page-item active"><a class="page-link" href="#"><?= $i ?></a></li>
                <?php else: ?>
                    <li class="page-item"><a class="page-link" href="?pagina=<?= $i ?>&busqueda=<?= urlencode($busqueda) ?>"><?= $i ?></a></li>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($pagina < $totalPaginas): ?>
                <li class="page-item">
                  <a class="page-link" href="?pagina=<?= $pagina + 1 ?>&busqueda=<?= urlencode($busqueda) ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                  </a>
                </li>
            <?php endif; ?>
          </ul>
        </nav>

        <?php
        // Estos enlaces solo los ven los administradores
        echo '<a href="?orden=asc&busqueda=' . urlencode($busqueda) . '" class="text-decoration-none text-primary ' . ($orden == 'asc' ? 'selected' : '') . '">Nombre Asc | </a>';
        echo '<a href="?orden=desc&busqueda=' . urlencode($busqueda) . '" class="text-decoration-none text-primary ' . ($orden == 'desc' ? 'selected' : '') . '">Nombre Desc</a><br><br>';
    endif;
    ?>
</main>

<?php
include "footer.php";
$con = null;
?>