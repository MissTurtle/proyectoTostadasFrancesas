<?php
session_start();
include "funciones.php";
include "header.php";
?>

<main class="container">
    <div class="panel panel-default">
        <div class="panel-body">
            <h2>Política de privacidad</h2>

            <p class="text-primary">Hola usuario/a de Current Task Flow.</p>

            <p class="text-primary">Esto es un gestor de proyectos y tareas realizado para mi TFG. Pero igual, aquí está nuestra política de privacidad.</p>

            <h3>Información que pedimos</h3>
            <p class="text-primary">La información que pedímos es solo para que interactues con la página, no hace falta que pongas datos reales.</p>
            <p class="text-primary">Si te arrepientes de haber dado algún dato, basta con que entres a Gestión de Usuarios y lo cambies pulsando el icono de Editar. Nada de lo que pusiste anteriormente persistirá en ninguna parte.</p>

            <h3>¿Para qué usamos tu información?</h3>
            <p class="text-primary">Para nada...</p>

            <h3>¿Le damos tu información a alguien?</h3>
            <p class="text-primary">No, es más, te borraré de la base de datos en cuanto te vea, así que a la próxima empezarás de nuevo.</p>

            <h3>Seguridad</h3>
            <p class="text-primary">De todos modos, que sepas que los demás usuarios no podrán acceder a tu información.</p>
            <p class="text-primary">Lo he programado para que cualquiera que quiera probar la página quede registrado como un usuario común, siendo yo la administradora y la única con acceso a la información de todos.</p>
        </div>
    </div>
</main>

<?php
include "footer.php";
$con = null;
?>