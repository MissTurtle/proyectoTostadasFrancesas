<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include "funciones.php";
include "sendMail.php";

try {
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dni = $_POST["dni"];
    $email = $_POST["email"];

    $funciones = new Funciones();

    $jsAlert = "";
    $redirect = "";

    // Comprueba que el DNI cumple los requisitos
    if ($funciones->validarDNI($dni)) {
        try {
            // Consulta prepare
            $stmt = $con->prepare("SELECT dni, nombre, direccion, localidad, provincia, telefono, email FROM usuarios WHERE dni = :dni AND email = :email");
            $stmt->bindParam(":dni", $dni);
            $stmt->bindParam(":email", $email);
            $stmt->execute();

            $fila = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($fila) {
                // Generar una nueva contraseña temporal
                $newPassword = generateTemporaryPassword();
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Actualizar la contraseña en la base de datos
                $stmt = $con->prepare("UPDATE usuarios SET contrasenya = :hashedPassword WHERE dni = :dni AND email = :email");
                $stmt->bindParam(":hashedPassword", $hashedPassword);
                $stmt->bindParam(":dni", $dni);
                $stmt->bindParam(":email", $email);
                $stmt->execute();

                // Crear el mensaje con la nueva contraseña
                $userInfo = "Se ha generado una nueva contraseña para su cuenta:<br>" .
                            "Contraseña: " . $newPassword . "<br>" .
                            "Por favor, cambie esta contraseña una vez haya accedido a su cuenta.";

                // Asunto del correo
                $subject = "Recuperación de contraseña";

                // Enviar el correo
                $sendResult = sendMail($email, $subject, $userInfo);
                if ($sendResult === true) {
                    $jsAlert = "alert('La información ha sido enviada a su correo electrónico.');";
                    $redirect = "setTimeout(() => { window.location.href = 'index.php'; }, 2000);";
                } else {
                    $jsAlert = "alert('Error: No se pudo enviar el correo. " . $sendResult . "');";
                    $redirect = "window.location.href = 'olvideContrasenya.php';";
                }
            } else {
                $jsAlert = "alert('Error: DNI o email incorrectos.');";
                $redirect = "window.location.href = 'olvideContrasenya.php';";
            }
        } catch (PDOException $e) {
            $jsAlert = "alert('Error: " . $e->getMessage() . "');";
            $redirect = "window.location.href = 'olvideContrasenya.php';";
        }
    } else {
        $jsAlert = "alert('Error: DNI no válido.');";
        $redirect = "window.location.href = 'olvideContrasenya.php';";
    }

    echo "<script>$jsAlert $redirect</script>";
}

include "header.php";
?>

<main class="container">
    <h2>Introduce tus datos y te enviaremos tu nueva contraseña</h2>
    <form name="olvideContrasenya" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="dni" class="form-label">DNI</label>
            <input type="text" class="form-control w-25" name="dni" maxlength="9" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control w-25" name="email" maxlength="30" required>
        </div>
        <div class="mb-3">
            <input type="submit" class="btn btn-primary text-light" value="Recuperar Contraseña"><br><br>
        </div>
    </form>
</main>

<?php
include "footer.php";
$con = null;

function generateTemporaryPassword($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $temporaryPassword = '';
    for ($i = 0; $i < $length; $i++) {
        $temporaryPassword .= $characters[rand(0, $charactersLength - 1)];
    }
    return $temporaryPassword;
}
?>